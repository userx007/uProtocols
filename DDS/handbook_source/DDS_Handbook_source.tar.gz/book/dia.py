import subprocess, os, sys, re
OUT = "/home/claude/book/img"
FONT = "DejaVu Sans"
BASE = f'''
  graph [fontname="{FONT}", fontsize=13, bgcolor="white", pad=0.2, nodesep=0.35, ranksep=0.45];
  node  [fontname="{FONT}", fontsize=12, shape=box, style="filled,rounded", fillcolor="#f2f2f2", color="#333333", penwidth=1.3, margin="0.14,0.08"];
  edge  [fontname="{FONT}", fontsize=11, color="#333333", penwidth=1.3, arrowsize=0.8];
'''
def render(name, body, width_px=1100, extra=""):
    body = re.sub(r'#([0-9a-fA-F])([0-9a-fA-F])([0-9a-fA-F])(?![0-9a-fA-F])', lambda m: '#'+m.group(1)*2+m.group(2)*2+m.group(3)*2, body)
    dot = f'digraph G {{\n{BASE}\n{extra}\n{body}\n}}'
    p = os.path.join(OUT, name + ".dot")
    open(p, "w").write(dot)
    png = os.path.join(OUT, name + ".png")
    # dpi chosen so that natural size scales reasonably; then limit width
    subprocess.run(["dot", "-Tpng", "-Gdpi=170", p, "-o", png], check=True)
    subprocess.run(["convert", png, "-resize", f"{width_px}x>", "-colorspace", "Gray", "-colors", "64", png], check=True)

D = {}
# 1 entity hierarchy
D["hierarchy"] = ("""
 rankdir=TB;
 dom [label="DOMAIN  (Domain ID = 0)\\nhard isolation boundary", fillcolor="#dddddd"];
 dp  [label="DomainParticipant\\nfactory + identity of the application", fillcolor="#e8e8e8"];
 tp  [label="Topic\\nname + type + QoS", fillcolor="#ffffff"];
 pub [label="Publisher\\n(Partition, Presentation)", fillcolor="#f2f2f2"];
 sub [label="Subscriber\\n(Partition, Presentation)", fillcolor="#f2f2f2"];
 dw  [label="DataWriter\\nwrite() / dispose()", fillcolor="#ffffff"];
 dr  [label="DataReader\\nread() / take()", fillcolor="#ffffff"];
 dom -> dp; dp -> tp; dp -> pub; dp -> sub; pub -> dw; sub -> dr;
 dw -> tp [style=dashed, constraint=false, label=" bound to"];
 dr -> tp [style=dashed, constraint=false, label=" bound to"];
""", 900)

# 2 layer stack
D["layers"] = ("""
 rankdir=TB; node [width=4.6, shape=box, style="filled"];
 a [label="Application code\\nwrite(), take(), QoS, listeners", fillcolor="#ffffff"];
 b [label="DDS API layer\\nDomainParticipant, Topic, DataWriter ...", fillcolor="#eeeeee"];
 c [label="RTPS wire protocol\\nGUIDs, discovery, reliability, submessages", fillcolor="#dddddd"];
 d [label="Transport\\nUDP unicast/multicast, TCP, shared memory", fillcolor="#cccccc"];
 a -> b -> c -> d [arrowhead=none, penwidth=0];
""", 800)

# 3 broker vs DDS
D["broker_vs_dds"] = ("""
 rankdir=LR; compound=true;
 subgraph cluster_b { label="Broker-based"; style="rounded,dashed"; color="#555555";
   P1 [label="Producer"]; BR [label="BROKER\\n(in the data path,\\nsingle point of failure)", fillcolor="#cccccc"]; C1 [label="Consumer A"]; C2 [label="Consumer B"];
   P1 -> BR -> C1; BR -> C2; }
 subgraph cluster_d { label="DDS (brokerless)"; style="rounded,dashed"; color="#555555";
   P2 [label="Publisher"]; S1 [label="Subscriber A"]; S2 [label="Subscriber B"];
   P2 -> S1; P2 -> S2; }
""", 1000)

# 4 domains & partitions
D["domains_partitions"] = ("""
 rankdir=TB;
 subgraph cluster_0 { label="Domain 0"; style="rounded"; color="#333333";
   w1 [label="Writer\\nPartition \\"A\\""]; r1 [label="Reader\\nPartition \\"A\\"", fillcolor="#ffffff"]; r2 [label="Reader\\nPartition \\"B\\"", fillcolor="#ffffff"];
   w1 -> r1 [label=" match"]; w1 -> r2 [style=dashed, label=" no overlap:\\n no match", color="#888888", fontcolor="#555555"]; }
 subgraph cluster_1 { label="Domain 1"; style="rounded"; color="#333333";
   w2 [label="Writer\\nsame topic name"]; r3 [label="Reader\\nsame topic name", fillcolor="#ffffff"];
   w2 -> r3 [label=" match"]; }
 r1 -> w2 [style=invis];
""", 900)

# 5 discovery SPDP -> SEDP  (sequence-ish)
D["discovery"] = ("""
 rankdir=TB; node [shape=box];
 subgraph cluster_a { label="Participant A"; style="rounded"; color="#333333"; A1 [label="SPDP announce\\n(who I am, where to reach me)"]; A2 [label="SEDP: my writers\\nand readers (topic, type, QoS)"]; }
 subgraph cluster_b { label="Participant B"; style="rounded"; color="#333333"; B1 [label="SPDP announce"]; B2 [label="SEDP: my writers\\nand readers"]; }
 A1 -> B1 [dir=both, label=" 1. periodic multicast /\\n unicast peers"];
 A1 -> A2 [style=invis]; B1 -> B2 [style=invis];
 A2 -> B2 [dir=both, label=" 2. after participants know\\n each other (reliable)"];
 M [label="3. Match check per writer/reader pair:\\ntopic name, type, QoS, partition, security", fillcolor="#dddddd"];
 A2 -> M [style=dashed]; B2 -> M [style=dashed];
""", 1000)

# 6 QoS request/offered
D["qos_rxo"] = ("""
 rankdir=LR;
 W [label="DataWriter\\nOFFERS\\nRELIABLE", fillcolor="#e8e8e8"]; R1 [label="DataReader\\nREQUESTS\\nBEST_EFFORT", fillcolor="#ffffff"];
 R2 [label="DataReader\\nREQUESTS\\nRELIABLE", fillcolor="#ffffff"]; W2 [label="DataWriter\\nOFFERS\\nBEST_EFFORT", fillcolor="#e8e8e8"];
 W -> R1 [label=" MATCH\\n (offer exceeds request)"]; 
 W2 -> R2 [label=" NO MATCH\\n (offer too weak)", style=dashed, color="#777777", fontcolor="#444444"];
""", 1000)

# 7 keyed instances
D["instances"] = ("""
 rankdir=LR;
 T [label="Topic VehiclePosition\\n(key = vehicle_id)", fillcolor="#dddddd"];
 I1 [label="Instance vehicle_id=1\\nsamples: s1, s4, s7 ...", fillcolor="#ffffff"];
 I2 [label="Instance vehicle_id=2\\nsamples: s2, s5 ...", fillcolor="#ffffff"];
 I3 [label="Instance vehicle_id=3\\nsamples: s3, s6 ...", fillcolor="#ffffff"];
 T -> I1; T -> I2; T -> I3;
 N [shape=note, style=filled, fillcolor="#f8f8f8", label="History, Deadline, Ownership,\\nTime-Based Filter, Lifecycle\\nare applied PER INSTANCE"];
 I2 -> N [style=dotted, arrowhead=none];
""", 1000)

# 8 heartbeat/acknack sequence (matplotlib-like via dot is clumsy -> use PIL later)
# 9 multicast vs unicast
D["cast"] = ("""
 rankdir=LR;
 subgraph cluster_u { label="Unicast fan-out: N copies"; style="rounded,dashed"; color="#555555";
   WU [label="Writer"]; U1 [label="Reader 1"]; U2 [label="Reader 2"]; U3 [label="Reader 3"];
   WU -> U1 [label="copy 1"]; WU -> U2 [label="copy 2"]; WU -> U3 [label="copy 3"]; }
 subgraph cluster_m { label="Multicast: 1 copy"; style="rounded,dashed"; color="#555555";
   WM [label="Writer"]; G [label="multicast group\\n239.255.0.x", shape=ellipse, fillcolor="#dddddd"]; M1 [label="Reader 1"]; M2 [label="Reader 2"]; M3 [label="Reader 3"];
   WM -> G [label="1 copy"]; G -> M1; G -> M2; G -> M3; }
""", 1000)

# 10 ownership failover
D["ownership"] = ("""
 rankdir=LR;
 P [label="Primary writer\\nstrength 100\\n(owner)", fillcolor="#dddddd"]; B [label="Backup writer\\nstrength 50\\n(standing by)", fillcolor="#f4f4f4"];
 R [label="EXCLUSIVE reader\\nsees one stream", fillcolor="#ffffff"];
 P -> R [label=" delivered", penwidth=2.2]; B -> R [label=" suppressed", style=dashed, color="#888888", fontcolor="#555555"];
 X [shape=note, style=filled, fillcolor="#f8f8f8", label="Primary loses liveliness\\n=> backup becomes owner\\nautomatically"];
 P -> X [style=dotted, arrowhead=none];
""", 1000)

# 11 content filter
D["cft"] = ("""
 rankdir=LR;
 W [label="DataWriter\\n100 Hz positions"]; F [label="filter: speed > 80\\n(writer-side if supported)", shape=diamond, style=filled, fillcolor="#e0e0e0"]; 
 R1 [label="Reader: FastVehicles\\n(few samples)", fillcolor="#ffffff"]; N [label="dropped before\\nthe network", shape=plaintext, style=""];
 W -> F; F -> R1 [label=" matches"]; F -> N [style=dashed, label=" rest"];
""", 1000)

# 12 ROS 2 single robot
D["ros_robot"] = ("""
 rankdir=LR;
 L [label="Lidar node"]; C [label="Camera node"]; I [label="IMU node"];
 S [label="Sensor-fusion\\nnode", fillcolor="#dddddd"]; M [label="Motor controller", fillcolor="#ffffff"];
 L -> S [label=" BEST_EFFORT"]; C -> S [label=" BEST_EFFORT"]; I -> S [label=" BEST_EFFORT"];
 S -> M [label=" /cmd_vel\\n RELIABLE, KEEP_LAST(10)", penwidth=2.2];
""", 1000)

# 13 fleet bridge
D["fleet"] = ("""
 rankdir=TB;
 A [label="Robot A\\nDomain 1"]; B [label="Robot B\\nDomain 2"]; C [label="Robot C\\nDomain 3"];
 BR [label="Domain bridge /\\nRouting Service", fillcolor="#cccccc"]; FM [label="Fleet manager\\n(sees all robots via bridged topics)", fillcolor="#ffffff"];
 A -> BR; B -> BR; C -> BR; BR -> FM;
""", 900)

# 14 SCADA loop
D["scada"] = ("""
 rankdir=LR;
 S [label="PLC / sensor I/O"]; T1 [label="Control topic\\nKEEP_LAST(1)\\nDEADLINE 10 ms", shape=note, fillcolor="#f8f8f8", style=filled];
 C [label="SCADA controller\\ncomputes setpoint", fillcolor="#dddddd"]; T2 [label="Setpoint topic\\nRELIABLE\\nDEADLINE 10 ms", shape=note, fillcolor="#f8f8f8", style=filled]; A [label="Actuator"];
 F [label="deadline missed =>\\non_requested_deadline_missed()\\n=> fail-safe logic", shape=box, fillcolor="#ffffff"];
 S -> T1 -> C -> T2 -> A; A -> F [style=dashed];
""", 1100)

# 15 trading
D["trading"] = ("""
 rankdir=LR;
 F [label="Feed handler"]; P [label="Price topic\\nBEST_EFFORT, no batching", shape=note, style=filled, fillcolor="#f8f8f8"];
 A [label="Strategy A", fillcolor="#fff"]; B [label="Strategy B", fillcolor="#fff"]; R [label="Risk monitor", fillcolor="#fff"];
 F -> P [label=" shared memory\\n or low-latency UDP"]; P -> A; P -> B; P -> R;
""", 1000)

# 16 IoT building
D["iot"] = ("""
 rankdir=LR;
 S [label="Thousands of sensors\\nBEST_EFFORT, small payloads"]; G [label="Multicast group\\n+ batching (50 ms)", shape=ellipse, style=filled, fillcolor="#dddddd"];
 D1 [label="Dashboard\\nzone = 'Floor3'", fillcolor="#fff"]; D2 [label="Analytics", fillcolor="#fff"]; DN [label="... Reader N", fillcolor="#fff"];
 S -> G; G -> D1; G -> D2; G -> DN;
""", 1000)

# 17 healthcare
D["health"] = ("""
 rankdir=LR;
 M [label="Patient monitor\\nRELIABLE, ENCRYPT, SIGN"]; T [label="Bedside topic", shape=note, style=filled, fillcolor="#f8f8f8"];
 AC [label="Access control:\\nonly ICU_Display and\\nNursingStation may subscribe", shape=diamond, style=filled, fillcolor="#dddddd"];
 CS [label="Central station", fillcolor="#fff"]; AL [label="Alarm aggregator\\n(missed deadline => escalate)", fillcolor="#fff"];
 M -> T -> AC -> CS -> AL;
""", 1100)

# 18 WAN
D["wan"] = ("""
 rankdir=LR;
 subgraph cluster_a { label="Site A (Domain 0)"; style=rounded; color="#333333"; LA [label="Local DDS"]; RA [label="Routing Service A\\nfilter: battery_level < 20", fillcolor="#dddddd"]; LA -> RA; }
 subgraph cluster_b { label="Site B (Domain 1)"; style=rounded; color="#333333"; RB [label="Routing Service B\\nrepublishes locally", fillcolor="#dddddd"]; LB [label="Local DDS"]; RB -> LB; }
 RA -> RB [label=" WAN / TCP / VPN\\n only alerts cross", penwidth=2.4];
""", 1100)

# 19 security layers
D["security"] = ("""
 rankdir=TB; node [width=4.4];
 a [label="Application data", fillcolor="#ffffff"];
 b [label="Cryptographic: encrypt / sign (topic data, metadata)", fillcolor="#eeeeee"];
 c [label="Access control: governance + permissions XML", fillcolor="#e2e2e2"];
 d [label="Authentication: identity certificates (CA)", fillcolor="#d6d6d6"];
 e [label="Transport: UDP / TCP / shared memory (+ TLS on TCP)", fillcolor="#cccccc"];
 a -> b -> c -> d -> e [arrowhead=none, penwidth=0];
""", 900)

# 20 discovery mesh vs server
D["disc_scale"] = ("""
 rankdir=LR;
 subgraph cluster_m { label="Full mesh: n(n-1)/2 links"; style="rounded,dashed"; color="#555555";
   a1 [label="P1"]; a2 [label="P2"]; a3 [label="P3"]; a4 [label="P4"];
   a1 -> a2 [dir=both]; a1 -> a3 [dir=both]; a1 -> a4 [dir=both]; a2 -> a3 [dir=both]; a2 -> a4 [dir=both]; a3 -> a4 [dir=both]; }
 subgraph cluster_s { label="Discovery server: n links"; style="rounded,dashed"; color="#555555";
   S [label="Discovery\\nserver", fillcolor="#cccccc"]; b1 [label="P1"]; b2 [label="P2"]; b3 [label="P3"]; b4 [label="P4"];
   b1 -> S [dir=both]; b2 -> S [dir=both]; b3 -> S [dir=both]; b4 -> S [dir=both]; }
""", 1000)

# 21 xtypes appendable
D["xtypes"] = ("""
 rankdir=LR;
 V1 [label="Type v1 (writer)\\nid, lat, lon", fillcolor="#e8e8e8"]; V2 [label="Type v2 (writer)\\nid, lat, lon, speed\\n(appendable)", fillcolor="#e8e8e8"];
 R1 [label="Old reader (v1)\\nignores speed", fillcolor="#fff"]; R2 [label="New reader (v2)\\nspeed default if v1 writer", fillcolor="#fff"];
 V2 -> R1 [label=" OK"]; V1 -> R2 [label=" OK"];
""", 1000)

# 22 communication flow (internal)
D["flow"] = ("""
 rankdir=TB;
 subgraph cluster_p { label="Publisher process"; style=rounded; color="#333333"; a [label="write(sample)"]; b [label="DataWriter:\\nQoS checks, history cache,\\nsequence number"]; c [label="Serialize (CDR)\\n+ build RTPS message"]; a -> b -> c; }
 subgraph cluster_s { label="Subscriber process"; style=rounded; color="#333333"; d [label="Receive thread:\\nparse RTPS, match writer GUID"]; e [label="DataReader:\\ndeserialize, history cache,\\nfilters, instance state"]; f [label="Listener / WaitSet /\\ntake()"]; d -> e -> f; }
 c -> d [label=" transport:\\n UDP, shared memory, TCP", penwidth=2.2];
 d -> c [label=" ACKNACK\\n (RELIABLE only)", style=dashed, constraint=false];
""", 900)

# 23 troubleshooting flow
D["trouble"] = ("""
 rankdir=TB; node [shape=box];
 s [label="Reader receives no data", fillcolor="#cccccc"];
 q1 [label="1. Same Domain ID?", shape=diamond, fillcolor="#e8e8e8"]; 
 q2 [label="2. Same topic name AND type?", shape=diamond, fillcolor="#e8e8e8"];
 q3 [label="3. Partitions overlap?", shape=diamond, fillcolor="#e8e8e8"];
 q4 [label="4. incompatible-QoS\\nstatus fired?", shape=diamond, fillcolor="#e8e8e8"];
 q5 [label="5. Security / access\\ncontrol allows it?", shape=diamond, fillcolor="#e8e8e8"];
 q6 [label="6. Matched but no data:\\nHistory, Resource Limits,\\nfilters, Lifespan, Deadline", fillcolor="#ffffff"];
 f1 [label="Fix Domain ID", fillcolor="#fff"]; f2 [label="Fix names / types (XTypes)", fillcolor="#fff"]; f3 [label="Fix Partition", fillcolor="#fff"]; f4 [label="Fix policy named by\\nlast_policy_id", fillcolor="#fff"]; f5 [label="Fix permissions /\\ngovernance", fillcolor="#fff"];
 s -> q1; q1 -> q2 [label=" yes"]; q1 -> f1 [label=" no"];
 q2 -> q3 [label=" yes"]; q2 -> f2 [label=" no"];
 q3 -> q4 [label=" yes"]; q3 -> f3 [label=" no"];
 q4 -> f4 [label=" yes"]; q4 -> q5 [label=" no"];
 q5 -> q6 [label=" yes"]; q5 -> f5 [label=" no"];
""", 1000)

# 24 GUID
D["guid"] = ("""
 rankdir=LR; node [shape=record, style=filled, fillcolor="#f2f2f2"];
 g [label="{GUID  (16 bytes)}|{<p>GUID prefix (12 bytes)\\nidentifies the DomainParticipant|<e>Entity ID (4 bytes)\\nidentifies the entity inside it}"];
 e [label="{Entity ID}|{Entity key (3 bytes)\\ncounter / hash|Entity kind (1 byte)\\nwriter, reader, built-in ...}", fillcolor="#ffffff"];
 g:e -> e;
""", 1000)

# 25 RTPS message
D["rtps_msg"] = ("""
 rankdir=LR; node [shape=record, style=filled, fillcolor="#f2f2f2"];
 m [label="{One UDP datagram = one RTPS message}|{Header\\n20 bytes|INFO_TS|DATA|DATA|HEARTBEAT}"];
 h [label="{Header}|{\\"RTPS\\"\\n4 B|version\\n2 B|vendorId\\n2 B|guidPrefix\\n12 B}", fillcolor="#fff"];
 s [label="{Submessage}|{id\\n1 B|flags\\n1 B|length\\n2 B|content}", fillcolor="#fff"];
 m -> h [style=dotted]; m -> s [style=dotted];
""", 1100)

# 26 reliable path summary (state) - ownership of lease? -> liveliness lease
D["lease"] = ("""
 rankdir=LR;
 W [label="Writer / participant\\nasserts liveliness"]; T [label="lease_duration timer\\n(reader side)", shape=ellipse, fillcolor="#dddddd"];
 A [label="ALIVE", fillcolor="#fff"]; N [label="NOT ALIVE\\non_liveliness_changed\\ninstances -> NO_WRITERS", fillcolor="#cccccc"];
 W -> T [label=" renews"]; T -> A [label=" renewed in time"]; T -> N [label=" lease expires", style=dashed];
""", 1000)

# 27 instance state machine
D["inst_state"] = ("""
 rankdir=LR;
 A [label="ALIVE", fillcolor="#fff"]; D [label="NOT_ALIVE_DISPOSED", fillcolor="#cccccc"]; N [label="NOT_ALIVE_NO_WRITERS", fillcolor="#cccccc"];
 A -> D [label=" dispose()"]; A -> N [label=" last writer\\n unregisters / loses liveliness"];
 D -> A [label=" write() again", style=dashed, constraint=false]; N -> A [label=" a writer writes again", style=dashed, constraint=false];
""", 1100)

# 28 durability
D["durability"] = ("""
 rankdir=LR;
 V [label="VOLATILE\\nno history for late joiners", fillcolor="#fff"];
 TL [label="TRANSIENT_LOCAL\\nkept in the writer's memory", fillcolor="#eee"];
 T [label="TRANSIENT\\nkept by a durability service (RAM)", fillcolor="#ddd"];
 P [label="PERSISTENT\\nkept by a durability service (disk)", fillcolor="#ccc"];
 V -> TL -> T -> P [label=" stronger, costlier"];
""", 1100)

if __name__ == "__main__":
    only = sys.argv[1:] 
    for k,(body,w) in D.items():
        if only and k not in only: continue
        render(k, body, w)
        print("ok", k)
