import re, subprocess
import dia
from dia import D, render, OUT
# generic: flip LR->TB for the wide ones
for k in ["cft","durability","health","instances","iot","lease","ros_robot","scada","trading","wan","cast"]:
    body,w = D[k]
    D[k] = (body.replace("rankdir=LR","rankdir=TB"), 800)

D["guid"] = ("""
 rankdir=TB; node [shape=record, style=filled, fillcolor="#f2f2f2"];
 g [label="{GUID  (16 bytes)}|{GUID prefix (12 B)\\nidentifies the\\nDomainParticipant|Entity ID (4 B)\\nidentifies the entity\\ninside that participant}"];
 e [label="{Entity ID (4 bytes)}|{Entity key (3 B)\\ncounter or hash|Entity kind (1 B)\\nwriter / reader /\\nbuilt-in ...}", fillcolor="#ffffff"];
 g -> e [style=dotted];
""", 800)

D["rtps_msg"] = ("""
 rankdir=TB; node [shape=record, style=filled, fillcolor="#f2f2f2"];
 m [label="{One UDP datagram = one RTPS message}|{Header (20 B)|INFO_TS|DATA|HEARTBEAT}"];
 h [label="{RTPS header}|{\\"RTPS\\" 4 B|version 2 B|vendorId 2 B|guidPrefix 12 B}", fillcolor="#ffffff"];
 s [label="{Submessage}|{id 1 B|flags 1 B|length 2 B|content}", fillcolor="#ffffff"];
 m -> h [style=dotted]; m -> s [style=dotted];
""", 800)

D["hierarchy"] = ("""
 rankdir=TB; nodesep=0.25;
 dom [label="DOMAIN (Domain ID)\\nhard isolation boundary", fillcolor="#dddddd"];
 dp  [label="DomainParticipant\\nfactory + identity", fillcolor="#e8e8e8"];
 tp  [label="Topic\\nname + type + QoS", fillcolor="#ffffff"];
 pub [label="Publisher\\nPartition, Presentation", fillcolor="#f2f2f2"];
 sub [label="Subscriber\\nPartition, Presentation", fillcolor="#f2f2f2"];
 dw  [label="DataWriter\\nwrite(), dispose()", fillcolor="#ffffff"];
 dr  [label="DataReader\\nread(), take()", fillcolor="#ffffff"];
 dom -> dp; dp -> pub; dp -> sub; pub -> dw; sub -> dr; dp -> tp;
 dw -> tp [style=dashed, constraint=false]; dr -> tp [style=dashed, constraint=false];
""", 800)

D["trouble"] = ("""
 rankdir=TB; node [width=5.2, shape=box, style="filled,rounded", fillcolor="#f2f2f2"];
 s  [label="START: reader receives no data", fillcolor="#cccccc"];
 q1 [label="1. Same Domain ID on both sides?\\n(no: fix the Domain ID)"];
 q2 [label="2. Same topic name AND compatible type?\\n(no: fix names / types / XTypes)"];
 q3 [label="3. Partitions overlap?\\n(no: fix Partition QoS)"];
 q4 [label="4. Incompatible-QoS status fired?\\n(yes: fix policy named by last_policy_id)"];
 q5 [label="5. Security / access control allows it?\\n(no: fix permissions + governance)"];
 q6 [label="6. Matched, still nothing?\\nCheck History, Resource Limits, filters,\\nLifespan, Time-Based Filter, app logic", fillcolor="#dddddd"];
 s -> q1 -> q2 -> q3 -> q4 -> q5 -> q6;
""", 800)

D["durability"] = ("""
 rankdir=TB; node [width=4.6];
 V [label="VOLATILE\\nno history for late joiners", fillcolor="#ffffff"];
 TL [label="TRANSIENT_LOCAL\\nkept in the writer's memory", fillcolor="#eeeeee"];
 T [label="TRANSIENT\\nkept by a durability service (RAM)", fillcolor="#dddddd"];
 P [label="PERSISTENT\\nkept by a durability service (disk)", fillcolor="#cccccc"];
 V -> TL -> T -> P [label=" stronger, costlier"];
""", 800)

D["broker_vs_dds"] = (D["broker_vs_dds"][0].replace("rankdir=LR","rankdir=TB"), 800)
D["disc_scale"] = (D["disc_scale"][0].replace("rankdir=LR","rankdir=TB"), 800)
D["qos_rxo"] = (D["qos_rxo"][0], 800)
D["cast"] = (D["cast"][0] + " WU -> WM [style=invis];", 800)
D["broker_vs_dds"] = (D["broker_vs_dds"][0] + " P1 -> P2 [style=invis];", 800)
D["disc_scale"] = (D["disc_scale"][0] + " a1 -> S [style=invis];", 800)
D["instances"] = (D["instances"][0].replace("Topic VehiclePosition\\n(key = vehicle_id)","Topic (key = id)").replace("Instance vehicle_id=","Instance id=").replace("samples: s1, s4, s7 ...","s1, s4, s7 ...").replace("samples: s2, s5 ...","s2, s5 ...").replace("samples: s3, s6 ...","s3, s6 ..."), 800)


# heartbeat/acknack sequence diagram with matplotlib
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
def seq():
    fig, ax = plt.subplots(figsize=(6.6, 6.4), dpi=170)
    ax.set_xlim(0, 10); ax.set_ylim(0, 14.2); ax.axis("off")
    ax.text(2, 13.7, "Writer", ha="center", fontsize=13, weight="bold")
    ax.text(8, 13.7, "Reader", ha="center", fontsize=13, weight="bold")
    ax.plot([2,2],[0.3,13.3], color="#555", lw=1.4); ax.plot([8,8],[0.3,13.3], color="#555", lw=1.4)
    def arrow(y, x0, x1, txt, lost=False, dashed=False, ty=0.22):
        ax.annotate("", xy=(x1,y-1.0), xytext=(x0,y), arrowprops=dict(arrowstyle="-|>", lw=1.5, color="#222" if not lost else "#999", ls="--" if (lost or dashed) else "-"))
        ax.text(5, y-0.5+ty, txt, ha="center", va="bottom", fontsize=9.6, rotation=0, bbox=dict(fc="white", ec="none", pad=1.2))
    arrow(12.8, 2, 8, "DATA  seq=1")
    arrow(11.5, 2, 8, "DATA  seq=2   (lost on the network)", lost=True)
    ax.text(8.2, 10.55, "x", fontsize=14, color="#777", weight="bold")
    arrow(10.2, 2, 8, "DATA  seq=3")
    arrow(8.5, 2, 8, "HEARTBEAT  first=1, last=3")
    ax.text(8.3, 6.95, "Reader notices:\nhas 1 and 3, missing 2", fontsize=9, va="top")
    arrow(6.2, 8, 2, "ACKNACK  base=2  (missing: 2)")
    arrow(4.5, 2, 8, "DATA  seq=2   (retransmission only)")
    arrow(2.8, 8, 2, "ACKNACK  base=4  (nothing missing)")
    ax.text(5, 0.0, "time flows downward", ha="center", fontsize=9, style="italic", color="#444")
    fig.savefig(OUT+"/heartbeat.png", bbox_inches="tight", facecolor="white")
seq()
if __name__ == "__main__":
    for k,(body,w) in D.items():
        render(k, body, w)
    subprocess.run(["convert", OUT+"/heartbeat.png", "-resize","1000x>","-colorspace","Gray", OUT+"/heartbeat.png"])
    out = subprocess.run("for f in %s/*.dot; do n=$(basename $f .dot); w=$(dot -Tpng -Gdpi=170 $f | identify -format '%%w x %%h' png:-); echo $n $w; done" % OUT, shell=True, capture_output=True, text=True).stdout
    print(out)
