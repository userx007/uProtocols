# 39. DDS Use Cases: A Visual Atlas {#ch39}

## Overview

Each figure below shows one architecture or mechanism. Read the labels on the arrows: they are the QoS choices, and they explain why that flow is configured the way it is.

## 1. Core Pub/Sub Decoupling (vs. Broker-Based Messaging)

![Broker-based messaging versus brokerless DDS](img/broker_vs_dds.png){width=100%}

With a broker, every message takes an extra hop through a process that must be operated, scaled and kept alive. With DDS, publishers and subscribers connect directly after discovery. See topic 01.

## 2. Domain and Partition Isolation

![Domains are hard walls; partitions are soft filters](img/domains_partitions.png){width=85%}

Entities in different **domains** never discover each other. Within one domain, a writer and reader with the same topic match only if their **partitions** overlap. See topics 02 and 13.

## 3. Two-Tier Discovery: SPDP, then SEDP

![SPDP finds participants, SEDP matches endpoints](img/discovery.png){width=100%}

First participants learn that each other exist (SPDP). Only then do they exchange endpoint details (SEDP) and run the match check. See topics 20 and 21.

## 4. QoS Request vs. Offered

![A writer's offer must meet the reader's request](img/qos_rxo.png){width=100%}

A `RELIABLE` writer can serve a `BEST_EFFORT` reader. The reverse does not match, and the mismatch is silent unless you listen for the status event. See topic 15.

## 5. Keyed Instances: One Topic, Many Independent Streams

![A keyed topic contains one instance per key value](img/instances.png){width=85%}

Each key value is its own instance with its own history, deadline and ownership. See topics 24 and 43.

## 6. Reliable Delivery: HEARTBEAT, ACKNACK, Retransmit

![A lost sample is detected and repaired](img/heartbeat.png){width=90%}

Sample 2 is lost. The HEARTBEAT announces what exists, the ACKNACK names what is missing, and only sample 2 is retransmitted. See topic 18.

## 7. Multicast Fan-Out vs. Unicast Fan-Out

![One copy to a group versus one copy per reader](img/cast.png){width=100%}

Multicast scales with a constant number of copies, but only if the network supports it. See topic 28 and Appendix D.

## 8. Ownership Strength: Hot/Warm Standby Failover

![The strongest live writer is heard; the backup takes over on failure](img/ownership.png){width=100%}

The backup is suppressed while the primary is alive. When the primary loses liveliness, the backup is promoted automatically. See topics 11, 12 and 38.

## 9. Content-Filtered Topic: Writer-Side Savings

![Only matching samples cross the network](img/cft.png){width=85%}

If the vendor supports writer-side filtering, non-matching samples are never sent to that reader. See topic 35.

## 10. Robotics / ROS 2: Sensor Fusion on One Robot

![High-rate sensors use BEST_EFFORT, commands use RELIABLE](img/ros_robot.png){width=95%}

Sensor streams are best-effort because a newer reading supersedes an older one. The command stream is reliable because every command matters. See topic 37.

## 11. Multi-Robot Fleet: Domain Isolation Plus an Explicit Bridge

![Each robot is its own domain; a bridge shares selected topics](img/fleet.png){width=80%}

Isolation keeps robots from cross-talking. The bridge decides which topics the fleet manager can see. See topic 30.

## 12. Industrial / SCADA: A Deterministic Control Loop

![A 10 ms deadline guards the loop](img/scada.png){width=60%}

If the deadline is missed, the reader's `on_requested_deadline_missed` fires and the fail-safe logic takes over. See topic 10.

## 13. Financial Trading: Low-Latency Market Data

![Latency over throughput: no batching, shared memory or fast UDP](img/trading.png){width=90%}

Every tick is sent immediately. Batching is deliberately off because it adds delay. See topic 29.

## 14. IoT / Smart Building: High Fan-Out, Low Bandwidth

![Many sensors, multicast, batching and per-dashboard filters](img/iot.png){width=90%}

Small best-effort samples, batching to cut packet counts, and content filters so each dashboard sees only its zone. See topics 28, 29 and 35.

## 15. Healthcare / Medical Devices: Reliable and Secure

![Reliable delivery, encryption and access control around a bedside topic](img/health.png){width=90%}

Only authenticated, authorised participants may subscribe. Missed deadlines escalate to an alarm. See topics 31 to 33.

## 16. WAN Bridging Across Sites

![Routing services forward only alert-worthy samples over the WAN](img/wan.png){width=70%}

Each site stays in its own domain. Filtering at the border keeps the expensive link for what matters. See topic 30.

## 17. Security Layering (Defense in Depth)

![Authentication, access control and cryptography stacked above the transport](img/security.png){width=80%}

Each layer is a separate plug-in and each protects against a different failure. See topics 31 to 33.

## 18. Discovery Scalability: Mesh vs. Discovery Server

![Full mesh grows as n squared; a discovery server grows as n](img/disc_scale.png){width=100%}

A discovery server replaces most pairwise announcements with one connection per participant. See topic 22.

## 19. Type Evolution with XTypes (Appendable)

![Old and new readers and writers keep working](img/xtypes.png){width=90%}

Adding a field at the end of an appendable type lets old readers ignore it and new readers fill in a default. See topic 26.

## Which Figure Maps to Which Use Case

| Figure | Use it to explain |
|---|---|
| 1, 18 | Why DDS needs no broker and how discovery scales |
| 2, 3, 4 | How endpoints find and match each other |
| 5, 6 | Instances and reliable delivery |
| 7, 9, 14 | Efficient delivery to many readers |
| 8, 12, 15 | Failover, deadlines and safety |
| 10, 11, 16 | Robots, fleets and sites |
| 13 | Latency-first design |
| 17 | Security |
| 19 | Type evolution |
