# 41. DDS Configuration and QoS Profiles {#ch41}

## Overview

DDS behaviour comes from two kinds of configuration, and keeping them apart avoids a lot of confusion.

1. **Middleware configuration**: network interfaces, discovery peers, multicast on or off, transports, logging, security files. This is *vendor-specific*, and each vendor has its own format.
2. **QoS configuration**: the reliability, durability, history and other policies of individual entities. The DDS-XML specification defines a standard XML format for QoS profiles, but not every vendor reads it.

## Middleware Configuration by Vendor

| Vendor | Typical mechanism |
|---|---|
| Eclipse Cyclone DDS | One XML file, selected with the `CYCLONEDDS_URI` environment variable (a file URI or inline XML) |
| eProsima Fast DDS | XML profiles file, selected with `FASTRTPS_DEFAULT_PROFILES_FILE` |
| RTI Connext | `USER_QOS_PROFILES.xml` in the working directory, or paths in `NDDS_QOS_PROFILES` |

### A minimal Cyclone DDS configuration

```xml
<CycloneDDS xmlns="https://cdds.io/config">
  <Domain id="any">
    <General>
      <Interfaces>
        <NetworkInterface name="eth0"/>
      </Interfaces>
      <AllowMulticast>default</AllowMulticast>
    </General>
    <Discovery>
      <Peers>
        <Peer address="192.168.1.10"/>
      </Peers>
    </Discovery>
    <Tracing>
      <Verbosity>config</Verbosity>
      <OutputFile>cdds.log</OutputFile>
    </Tracing>
  </Domain>
</CycloneDDS>
```

What each part does:

- `Domain id="any"` applies the settings to every domain this process joins.
- `NetworkInterface` selects which network card DDS uses. On machines with several interfaces (Wi-Fi, Ethernet, Docker bridges) this is one of the most common fixes for "nodes cannot see each other".
- `AllowMulticast` controls multicast. Set it to `false` where multicast is blocked.
- `Peers` lists unicast discovery peers, for networks without multicast (topic 22).
- `Tracing` writes a configuration dump and log. With `Verbosity` set to `config`, the log starts by listing every effective setting, which is the quickest way to verify that your file was actually read.

Element names changed between Cyclone DDS releases. Check the documentation of the version you run.

## A Library of QoS Patterns

Teams often define a small set of **named QoS profiles** and give each topic one of them, so that nobody has to reason about individual policies each time. The set below is one widely used example. The names are a *convention*. They are not defined by the DDS standard, and they are not ROS 2's own presets.

| Profile | For | Key settings |
|---|---|---|
| **State** | Current status of a component | `RELIABLE`, `TRANSIENT_LOCAL`, `KEEP_LAST`, ordered by source timestamp |
| **Command** | Short-lived control commands | `RELIABLE`, `VOLATILE`, `KEEP_ALL`, `LIFESPAN` of about 2 s |
| **Event** | Notifications, logs | Defaults (`BEST_EFFORT`-leaning, `VOLATILE`), `KEEP_LAST` |
| **Alarm** | Critical alerts | `RELIABLE`, `TRANSIENT_LOCAL`, `KEEP_ALL`, ordered by source timestamp |
| **Periodic** | High-rate sensors, telemetry | `BEST_EFFORT`, zero latency budget, ordered by source timestamp |
| **Watchdog** | Heartbeats and keep-alives | `RELIABLE`, ordered by source timestamp; deadline left to the application |
| **Specification** | Rarely changing configuration | `RELIABLE`, `TRANSIENT_LOCAL`, `KEEP_LAST` depth 1 |

Two notes on this table:

- Some sets of profiles specify `PERSISTENT` durability for configuration data. Stacks without a durability service downgrade it to `TRANSIENT_LOCAL`, which is why you may see that substitution with a comment in such files.
- `autodispose_unregistered_instances = false` in the writer data lifecycle QoS means that when a writer unregisters an instance, the instance is *not* automatically disposed. Readers therefore keep the last value and see `NO_WRITERS` rather than `DISPOSED`. This is useful when a publisher restarts and you do not want readers to treat the data as deleted.

### How an application picks a profile

The code should not contain `if (profile == "StatePattern")`. The usual approaches are:

- **Profile by name, loaded from XML**, where the vendor supports it. In RTI Connext and Fast DDS you reference a profile such as `Library::Profile` when creating the entity.
- **A small helper in your own code** that maps a topic or message category to a QoS object. Everything that creates writers and readers uses the helper, so changing a policy for one category is a one-line change.
- **ROS 2**: the QoS is set in code through `rclcpp::QoS` and preset profiles, and can be overridden at launch time with the `qos_overrides` parameters for individual topics. ROS 2 does not load these DDS XML profile libraries for you through `rmw_cyclonedds_cpp`.

Whichever you choose, derive the writer's and reader's QoS from one shared profile per topic. It makes incompatible QoS impossible by construction (topic 15).

## Summary

Separate middleware configuration (network, discovery, transports, logging; vendor-specific) from QoS configuration (policies; standard XML format exists but is not read by every stack). A small library of named QoS profiles keeps designs consistent. Verify the effective configuration with the vendor's configuration dump.

## Things to Remember

- **Two kinds of configuration**: middleware (vendor-specific) and QoS (policy-based).
- **Select the Cyclone DDS file with `CYCLONEDDS_URI`**; Fast DDS uses `FASTRTPS_DEFAULT_PROFILES_FILE`; RTI uses `NDDS_QOS_PROFILES` or `USER_QOS_PROFILES.xml`.
- **Choose the network interface explicitly** on multi-homed machines.
- **Turn on the config dump** to see which settings are really in effect.
- **Pattern names such as State and Command are conventions**, not standards.
- **Derive writer and reader QoS from one profile per topic**.
