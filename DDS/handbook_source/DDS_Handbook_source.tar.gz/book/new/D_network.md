# Appendix D: Networking Primer: Unicast and Multicast {#appD}

DDS discovery and fan-out lean heavily on multicast, so a basic grasp of how Ethernet and IP deliver it explains many "works on my laptop" failures.

## Unicast, Multicast, Broadcast

**Unicast** is one sender to one receiver. The destination is one specific network interface, and only that device processes the frame.

**Multicast** is one sender to a group. A device receives group traffic only after it has *joined* the group. A single copy leaves the sender and the network replicates it only where receivers exist.

**Broadcast** goes to every device on the local network. Multicast is the targeted version of it.

| | Unicast | Multicast |
|---|---|---|
| Destination | One device | A group of devices |
| Copies for N readers | N | 1 |
| Needs group management | No | Yes (IGMP, snooping, sometimes PIM) |
| Typical DDS use | Reliable repair, TCP, WAN | Discovery, high fan-out data |

## How IPv4 Multicast Reaches Ethernet

IPv4 multicast addresses are in the range 224.0.0.0 to 239.255.255.255. The Ethernet multicast MAC address is built from the fixed prefix `01:00:5E` plus the low 23 bits of the IP address. DDS's default discovery group, 239.255.0.1, falls in the administratively scoped range, which is meant for use inside an organisation.

## Joining a Group: IGMP

A host that wants a group sends an **IGMP membership report**.

- In IGMPv2 the report is sent to the **group address itself**. In IGMPv3 reports go to 224.0.0.22. (A *leave* message in IGMPv2 goes to 224.0.0.2, the all-routers group.)
- IGMP messages are link-local, with a TTL of 1. They never cross a router.
- A **querier** (normally a router or a configured switch) periodically asks "who still wants which group?". Hosts answer with reports. Silence causes the group to be pruned.

## Switches: IGMP Snooping

Without help, a switch floods multicast to every port, like broadcast. With **IGMP snooping**, the switch listens to the reports and forwards a group only to the ports that joined. Snooping needs a querier on the segment. When snooping is on and no querier exists, multicast delivery can silently stop after a few minutes, which is a classic cause of DDS discovery that works for a while and then fails.

## Across Routers

Multicast does not cross routers unless multicast routing (for example **PIM**) is configured. Many corporate and cloud networks do not offer it. For such networks, use unicast peers or a discovery server (topic 22), or route selected topics through a bridge (topic 30).

## What This Means for DDS

- **Discovery on one LAN** usually just works with multicast.
- **No multicast** (cloud, VPN, many Wi-Fi networks): configure unicast peers.
- **Large reader counts** benefit from multicast data delivery, if the switches handle it.
- **Repairs** of lost reliable samples still travel by unicast.
- **TTL** for DDS multicast can be configured when traffic must pass beyond one hop.

## Things to Remember

- **Multicast needs group membership** (IGMP) and a switch that understands it (snooping plus a querier).
- **IGMP reports go to the group (v2) or 224.0.0.22 (v3)**; IGMP stays link-local.
- **Multicast does not cross routers by default.**
- **When multicast fails, use unicast peers or a discovery server.**
