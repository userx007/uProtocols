# Appendix B: Cheat Sheets {#appB}

One-page facts for quick lookup. Defaults listed are those of the DDS specification; vendors and ROS 2 may differ, so verify them for your stack.

## B.1 QoS Policies at a Glance

Each entry reads: **Policy** (where it is set; whether it can change after creation; matching rule). Defaults follow.

**Reliability** (Topic, Writer, Reader; immutable; offered at least requested)
: `BEST_EFFORT` or `RELIABLE`. Spec default: Reader `BEST_EFFORT`, Writer `RELIABLE`. ROS 2 defaults both to reliable.

**Durability** (Topic, Writer, Reader; immutable; offered at least requested)
: `VOLATILE` < `TRANSIENT_LOCAL` < `TRANSIENT` < `PERSISTENT`. Default `VOLATILE`.

**History** (Topic, Writer, Reader; immutable; not part of matching)
: `KEEP_LAST` with depth, or `KEEP_ALL`. Default `KEEP_LAST`, depth 1.

**Resource Limits** (Topic, Writer, Reader; immutable; not part of matching)
: `max_samples`, `max_instances`, `max_samples_per_instance`. Default unlimited.

**Deadline** (Topic, Writer, Reader; mutable; offered period at most requested)
: Maximum time between updates per instance. Default infinite.

**Liveliness** (Topic, Writer, Reader; immutable; kind at least requested, lease at most requested)
: `AUTOMATIC` < `MANUAL_BY_PARTICIPANT` < `MANUAL_BY_TOPIC`, plus `lease_duration`. Default `AUTOMATIC`, infinite lease.

**Ownership** (Topic, Writer, Reader; immutable; exact match)
: `SHARED` or `EXCLUSIVE`. Default `SHARED`.

**Ownership Strength** (Writer; mutable; not matched)
: Integer. The highest live strength wins under `EXCLUSIVE`. Default 0.

**Partition** (Publisher, Subscriber; mutable; names must overlap)
: List of strings, wildcards allowed. Default: empty string.

**Lifespan** (Topic, Writer; mutable; not part of matching)
: Expiry time for samples. Default infinite.

**Time-Based Filter** (Reader; mutable; not part of matching)
: `minimum_separation` per instance. Default 0 (no filtering).

**Latency Budget** (Topic, Writer, Reader; mutable; offered at most requested)
: Hint for acceptable delay. Default 0.

**Destination Order** (Topic, Writer, Reader; immutable; offered at least requested)
: `BY_RECEPTION_TIMESTAMP` < `BY_SOURCE_TIMESTAMP`. Default by reception.

**Presentation** (Publisher, Subscriber; immutable; offered at least requested)
: `access_scope` (`INSTANCE`, `TOPIC`, `GROUP`), `coherent_access`, `ordered_access`.

**Writer Data Lifecycle** (Writer; mutable; not matched)
: `autodispose_unregistered_instances`, default true.

## B.2 Compatibility in One Table

| Rule | Policies |
|---|---|
| Offered must be at least as strong as requested | Reliability, Durability, Deadline (period shorter is stronger), Liveliness (kind and lease), Latency Budget, Destination Order, Presentation |
| Exact match | Ownership |
| Names must overlap | Partition |
| Not part of matching | History, Resource Limits, Lifespan, Time-Based Filter |

## B.3 Default Discovery Ports (RTPS)

The standard port mapping uses these constants.

| Constant | Value |
|---|---|
| PB (port base) | 7400 |
| DG (domain gain) | 250 |
| PG (participant gain) | 2 |
| d0 | 0 |
| d1 | 10 |
| d2 | 1 |
| d3 | 11 |

| Purpose | Formula |
|---|---|
| Discovery multicast | PB + DG × domainId + d0 |
| Discovery unicast | PB + DG × domainId + d1 + PG × participantId |
| User-data multicast | PB + DG × domainId + d2 |
| User-data unicast | PB + DG × domainId + d3 + PG × participantId |

Worked example for domain 5: discovery multicast port is 7400 + 250 × 5 = **8650**. The default discovery multicast address is **239.255.0.1**.

Firewalls: open UDP for this range (for example 7400 to 7500 for low domain IDs), and allow the multicast group.

## B.4 Choosing QoS by Kind of Data

| Data | Reliability | Durability | History | Extras |
|---|---|---|---|---|
| High-rate sensor stream | `BEST_EFFORT` | `VOLATILE` | `KEEP_LAST` 1 | Time-Based Filter for slow consumers |
| Current state of a component | `RELIABLE` | `TRANSIENT_LOCAL` | `KEEP_LAST` 1 | Deadline if staleness matters |
| Configuration | `RELIABLE` | `TRANSIENT_LOCAL` | `KEEP_LAST` 1 | Needs the writer to stay alive; use `TRANSIENT` otherwise |
| Command | `RELIABLE` | `VOLATILE` | `KEEP_ALL` | Short Lifespan so old commands never arrive late |
| Alarm / event | `RELIABLE` | `TRANSIENT_LOCAL` | `KEEP_ALL` | Source-timestamp ordering |
| Heartbeat of a service | `RELIABLE` | `VOLATILE` | `KEEP_LAST` 1 | Liveliness with a lease |
| Redundant source | any | any | any | `EXCLUSIVE` ownership plus liveliness |

## B.5 Reader Sample States

| Dimension | Values |
|---|---|
| Sample state | `READ`, `NOT_READ` |
| View state | `NEW`, `NOT_NEW` |
| Instance state | `ALIVE`, `NOT_ALIVE_DISPOSED`, `NOT_ALIVE_NO_WRITERS` |

## B.6 RTPS Submessages

| Name | Meaning |
|---|---|
| `DATA` | One serialized sample (or key only) |
| `DATA_FRAG` | One fragment of a large sample |
| `HEARTBEAT` | Writer: "I hold sequence numbers first to last" |
| `ACKNACK` | Reader: "I have everything below base; these are missing" |
| `GAP` | Writer: "these sequence numbers will never come" |
| `INFO_TS` | Timestamp for the following DATA |
| `INFO_DST` | Destination participant for what follows |
| `NACK_FRAG`, `HEARTBEAT_FRAG` | Fragment-level equivalents |
