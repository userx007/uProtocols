# 40. Internal Communication Flow, Step by Step {#ch40}

## Overview

From your code's point of view, `write()` returns and a reader somewhere calls `take()`. In between, a fixed sequence of steps runs. Knowing the sequence tells you where to look when data is late, missing or duplicated.

The steps are the same for every conformant vendor, because they are defined by the DDS specification and the RTPS wire protocol. Library-specific details are flagged as such.

## The Components Involved

1. **Application code**: creates entities, calls `write()` and `take()`.
2. **DDS API layer**: the vendor library linked into your process.
3. **DataWriter and DataReader internals**: history caches, QoS enforcement, sequence numbering.
4. **RTPS layer**: builds and parses messages and runs discovery and reliability.
5. **Transport**: UDP, shared memory or TCP.
6. **Operating system**: sockets, or shared memory segments.

## Phase 1: Discovery (Before Any Data Flows)

1. A process creates a DomainParticipant. It starts **SPDP**: it announces its GUID prefix, protocol version, vendor ID and addresses (locators) to the well-known multicast address and to any configured unicast peers. Announcements repeat periodically (topic 20).
2. Participants that hear each other on the same domain add each other to their discovery databases.
3. They then run **SEDP** over built-in reliable writers and readers. Each side learns the other's writers and readers: topic name, type, QoS (topic 21).
4. For every writer/reader pair, each side checks **topic, type, QoS compatibility, partition overlap and security**. A compatible pair is *matched*, and the application gets `on_publication_matched` or `on_subscription_matched`.

There are no "hello" and "hello-ack" messages in the RTPS sense. SPDP is a periodic one-way announcement, and SEDP is ordinary RTPS data exchange between built-in endpoints.

## Phase 2: What Happens on write()

![The path of one sample from writer to reader](img/flow.png){width=85%}

1. **Checks.** The DataWriter checks QoS limits (for example `RESOURCE_LIMITS`). A `RELIABLE` writer with a full history may block for up to `max_blocking_time` (topic 07).
2. **History.** The sample is stored in the writer's history cache and gets the next **sequence number** (topic 18).
3. **Serialization.** The sample is encoded with CDR (topic 25).
4. **Message building.** An RTPS message is built: header, optional `INFO_TS`, then a `DATA` submessage. Large samples become `DATA_FRAG` submessages (topic 17).
5. **Transport.** The message goes out over the transport chosen for each matched reader: UDP unicast or multicast, shared memory, or TCP (topic 27).
6. **Receive.** The reader's receive thread parses the message, finds the target reader by GUID and discards samples that the reader should not receive (for example filtered or duplicate samples).
7. **Reader cache.** The sample is deserialized and stored in the DataReader's history cache with its `SampleInfo` (sample, view and instance state).
8. **Delivery.** The application is informed through a listener, a WaitSet condition, or simply finds the sample on its next `read()` or `take()`.

## What Differs by Reliability

**BEST_EFFORT.** After step 5, the writer does nothing more. If a packet is lost, the sample is gone.

**RELIABLE.** The writer keeps the sample in its history cache and periodically sends a `HEARTBEAT`. The reader answers with an `ACKNACK` that names any missing sequence numbers, and the writer retransmits only those. Acknowledgements are per sequence number, not "ACK per packet". The writer may drop a sample from its cache once all matched reliable readers have acknowledged it and the history policy allows it (topics 09 and 18).

## Transport Choice and What You Can See

The transport is chosen per matched pair, based on the locators exchanged during discovery.

- **Different hosts.** UDP (or TCP) goes through the network interface, so Wireshark sees it.
- **Same host, UDP.** Traffic goes through the loopback interface (`lo`). Capture on `lo`, not on the physical interface.
- **Same host, shared memory.** Samples are placed in a shared segment, so no UDP data packets appear at all. Discovery usually still appears as UDP.

Whether shared memory is used by default depends on the vendor and the build. Some stacks enable it by default; others require an extra component and explicit configuration. For Eclipse Cyclone DDS, shared memory depends on the Iceoryx integration and must be enabled in the configuration. If a capture shows discovery but no data on the same host, shared memory is the likely explanation. To check, temporarily disable it in the configuration and capture again.

## Summary

Discovery first finds participants (SPDP) and then matches endpoints (SEDP). A write passes through QoS checks, history, serialization, RTPS message building and a transport. On the way back, RELIABLE flows add HEARTBEAT and ACKNACK. The visible traffic depends on the transport chosen per pair.

## Things to Remember

- **Discovery precedes data**: SPDP finds participants, SEDP matches endpoints.
- **Every write** gets a per-writer sequence number and enters the writer's history cache.
- **RELIABLE** adds HEARTBEAT and ACKNACK with selective retransmission; **BEST_EFFORT** never retransmits.
- **Transport is chosen per matched pair**: same host may use loopback UDP or shared memory.
- **No data in a capture on the same host** usually means shared memory (or you captured the wrong interface).
- **Shared-memory defaults are vendor- and build-specific**; verify them, do not assume.
