# About This Book {#preface .unnumbered}

This handbook has two jobs.

**First, it teaches.** Every chapter opens with a one-sentence summary and a plain-language analogy, then explains the idea properly, with the code, configuration and protocol details a working engineer needs.

**Second, it is a reference you can come back to.** Every chapter ends with a short list of things to remember, and the appendices collect the facts you look up most often: compatibility rules, port formulas, a troubleshooting checklist, a networking primer and a glossary.

## How the chapters are built

Each chapter follows the same pattern, so you always know where to look.

::: keybox
**In one sentence.** The whole chapter, compressed to a line you can reread in five seconds.
:::

::: analogy
**Analogy.** A familiar picture (a post office, a dead-man's switch, a spreadsheet) that carries the core idea. Analogies are teaching aids. Where they stop being accurate, the main text takes over.
:::

Then come the detailed sections, a **Summary**, and **Things to Remember**, which is the part to reread when you need a fast refresh.

## Three ways to read it

**Learning from scratch.** Read Parts I and II in order (chapters 1 to 15). Skim Part III (the wire protocol) on the first pass and return to it when you start debugging. Chapter 43 is a good companion to chapter 24.

**Brushing up before a design review or interview.** Read the *In one sentence* and *Analogy* boxes of every chapter, then use Appendix A, *The Refresher*, which collects every chapter's *Things to Remember* in one place.

**Debugging right now.** Go to Appendix C (*Troubleshooting*), then chapters 15, 36 and 18, in that order.

## Conventions

- Chapter references such as *topic 24* are links. Tap them to jump.
- Code is C++-style pseudocode unless stated otherwise. Long lines are wrapped and the continuation is indented, so a wrapped line is still one statement.
- QoS names are shown the way the specification writes them (`RELIABLE`, `KEEP_LAST`). Exact API spellings differ between vendors.
- Behaviour that depends on the vendor is marked as such. Your vendor's documentation always wins over this book for defaults and config syntax.
- Diagrams are images so that they stay readable on an e-reader. Tap an image to enlarge it.

## A word on versions and accuracy

The text follows the OMG DDS specification (version 1.4), the DDSI-RTPS wire protocol and the DDS Security and XTypes specifications. Vendors cover these to different degrees, and defaults change between releases. When a number matters (a default, a port, a timeout), verify it against the version you are running.
