# Appendix C: Troubleshooting Checklist {#appC}

## Reader Receives No Data

![Work through the checks in this order](img/trouble.png){width=90%}

Work through the checks top to bottom. Most problems are found in the first four.

1. **Domain ID.** Confirm both sides use the same value. In ROS 2 this is `ROS_DOMAIN_ID`.
2. **Topic name and type.** Names are case-sensitive and, in ROS 2, include the namespace. Types must match or be XTypes-compatible.
3. **Partition.** Two entities match only if their partition lists overlap. Remember that the default partition does not match a non-empty one.
4. **QoS.** Listen for `on_requested_incompatible_qos` and `on_offered_incompatible_qos`. The `last_policy_id` field names the offending policy.
5. **Security.** If DDS Security is on, check certificates, governance and permissions.
6. **Matched but still silent.** Then the problem is after matching: History and Resource Limits dropping samples, content filters, Lifespan expiring samples, a Time-Based Filter throttling, or application logic (for example calling `read()` with a sample-state mask that excludes what you want).

## Matching Works, But the Network Is the Problem

- **Multicast blocked** (typical in clouds, VPNs, Wi-Fi with client isolation): configure unicast peers or a discovery server.
- **Wrong interface** on multi-homed hosts: select the network interface explicitly.
- **Firewall**: allow the UDP ports from Appendix B.3.
- **Containers**: use host networking or configure peers; shared memory does not cross container namespaces unless the shared mount is arranged.

## Latency or Loss

| Symptom | Likely cause | First check |
|---|---|---|
| Reliable topic is slow | Heartbeat period too coarse, or retransmission storm | HEARTBEAT and ACKNACK cadence in Wireshark |
| `write()` blocks | Reliable writer with a full history and a slow reader | Resource Limits, `max_blocking_time` |
| Large samples drop | Fragment loss or small socket buffers | MTU, `DATA_FRAG` counts, receive buffer size |
| Frequent "lost" events | Lease too short for the network jitter | Liveliness lease and Deadline margins |
| Memory grows | `KEEP_ALL` with unlimited limits and a stuck reader | Resource Limits, disconnected readers |

## A Short Diagnostic Routine

1. Run your vendor's configuration dump and confirm the active settings.
2. List discovered participants and endpoints (built-in topics or a tool; see Appendix E).
3. Compare writer and reader QoS side by side.
4. Capture traffic on the correct interface and filter on `rtps`.
5. Only then change code.
