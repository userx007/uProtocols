import struct
NAMES = {0x01:"PAD",0x06:"ACKNACK",0x07:"HEARTBEAT",0x08:"GAP",
 0x09:"INFO_TS",0x0c:"INFO_SRC",0x0d:"INFO_REPLY_IP4",
 0x0e:"INFO_DST",0x0f:"INFO_REPLY",0x12:"NACK_FRAG",
 0x13:"HEARTBEAT_FRAG",0x15:"DATA",0x16:"DATA_FRAG"}

def decode(pkt: bytes):
    if pkt[:4] != b"RTPS":
        raise ValueError("not an RTPS packet")
    ver = (pkt[4], pkt[5])
    vendor = pkt[6:8].hex()
    prefix = pkt[8:20].hex()
    print(f"RTPS {ver[0]}.{ver[1]} vendor=0x{vendor} "
          f"prefix={prefix}")
    off = 20
    while off + 4 <= len(pkt):
        sid, flags = pkt[off], pkt[off + 1]
        little = bool(flags & 0x01)       # E flag
        fmt = "<H" if little else ">H"
        (length,) = struct.unpack_from(fmt, pkt, off + 2)
        if length == 0:                   # runs to end of packet
            length = len(pkt) - off - 4
        name = NAMES.get(sid, f"UNKNOWN(0x{sid:02x})")
        print(f"  {name:<14} flags=0x{flags:02x} len={length}")
        off += 4 + length