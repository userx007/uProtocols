# The Big Picture in One Page {#bigpicture .unnumbered}

Before the details, here is the whole of DDS as one story. Come back to this page whenever the details start to blur.

## The trade-fair story

Imagine a large **trade fair**.

- The fair has numbered **halls**. People in Hall 3 cannot hear anything said in Hall 5. That is a **Domain**, identified by a Domain ID.
- Each company sends a **delegate with a badge**. The badge proves who they are, and everything the company sets up is registered under it. That is a **DomainParticipant**.
- In the hall there are **bulletin boards**. Each board has a name and a printed form with fixed fields. That is a **Topic**, which is a name plus a data type.
- A form with a key field, such as *vehicle_id*, effectively has **one row per vehicle**. Each row is an **Instance**. A new note pinned on a row is a **Sample**.
- Staff who pin notes are **DataWriters**. Staff who copy notes are **DataReaders**. Their department managers are **Publishers** and **Subscribers**.
- Every staff member carries a **contract card** (QoS): how reliably they deliver, whether they keep copies for latecomers, how often they update, how long a note stays valid. Two staff members cooperate only if the writer's *offer* meets the reader's *requirement*.
- There is no reception desk. When people enter, they announce themselves (**SPDP**) and then swap manifests of what they carry (**SEDP**). That is **Discovery**.
- Everyone follows the same fair rulebook, no matter which vendor's pens they use. That is the **RTPS** wire protocol.

## The same story as a table

| Fair | DDS |
|---|---|
| Hall number | Domain ID |
| Delegate badge | DomainParticipant |
| Board with a form | Topic (name + type + QoS) |
| One row on the form | Instance (identified by key) |
| A note pinned on a row | Sample |
| Staff who pin / copy | DataWriter / DataReader |
| Department managers | Publisher / Subscriber |
| Contract card | QoS policies |
| Wristband colour | Partition |
| Shout of name at the door | SPDP |
| Exchange of manifests | SEDP |
| Fair rulebook | RTPS |

## The picture

![The DDS entity hierarchy](img/hierarchy.png){width=90%}

## The five sentences to remember

1. DDS shares **typed, live data** in a global data space; it does not pass opaque messages.
2. There is **no broker**: endpoints discover each other and talk directly.
3. **QoS contracts** are chosen per data flow, and a writer and reader connect only if the contracts are compatible.
4. **Keys and instances** let DDS track many independent things inside one topic.
5. **RTPS** is the standard wire protocol that makes different vendors interoperate.
