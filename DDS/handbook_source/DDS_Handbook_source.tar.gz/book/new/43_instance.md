# 43. Instances in DDS, Clarified {#ch43}

## Overview

The word *instance* confuses many newcomers, because in object-oriented programming it means "an object of a class". In DDS it means something different.

A DDS **instance** is one logical thing in the real world, identified by the **key** fields of the topic's data type. A **sample** is one observation of that thing's state.

## The Core Idea

- **Sample** = the current state or measurement (*Car 001 is going 50 km/h*).
- **Instance** = the persistent identity of the thing (*Car 001*).

All samples with the same key value belong to the same instance. A sample with a different key value belongs to a different instance.

| Sample | vehicle_id (key) | Speed | Belongs to |
|---|---|---|---|
| 1 | Car_001 | 50 | Instance Car_001 |
| 2 | Car_002 | 70 | Instance Car_002 |
| 3 | Car_001 | 55 | Instance Car_001 |
| 4 | Car_001 | 0 | Instance Car_001 |

Samples 1, 3 and 4 update the same instance. Sample 2 updates another one.

## Keyed and Non-Keyed Topics

Keys are declared in the **type definition**, in IDL with the `@key` annotation (topic 23).

```idl
struct VehicleStatus {
    @key string vehicle_id;
    double speed_kmh;
};
```

- **Keyed topic**: each distinct key value is one instance.
- **Non-keyed topic**: the whole topic behaves as a single instance. Every sample updates the same logical thing.

## Why Instances Matter

**Per-instance state.** The reader's cache holds samples grouped by instance. With `KEEP_LAST` and depth 1, the cache holds the latest state of every vehicle (topic 09).

**Per-instance QoS behaviour.** History, Deadline, Ownership, Time-Based Filter and Lifespan are evaluated per instance. A missed deadline is reported for *one* vehicle, not for the topic as a whole. Exclusive ownership can have a different owner for each vehicle (topic 12).

**Instance lifecycle.** An instance can be `ALIVE`, `NOT_ALIVE_DISPOSED` (a writer called `dispose()`, meaning the thing no longer exists) or `NOT_ALIVE_NO_WRITERS` (no live writer remains for it). See topic 24.

![The instance lifecycle](img/inst_state.png){width=100%}

**Late joiners.** With `TRANSIENT_LOCAL` and `KEEP_LAST` depth 1, a late reader receives the latest sample of *every* instance (topic 08).

## How Code Works With Instances

The exact API names differ between languages and vendors. The standard DDS C++ API has these concepts:

| Operation | Meaning |
|---|---|
| `register_instance(sample)` | Tell DDS about an instance up front and get an instance handle (an optimisation) |
| `write(sample)` | Update the instance identified by the key in the sample |
| `dispose(sample)` | The thing no longer exists |
| `unregister_instance(sample)` | This writer stops writing this instance |
| `lookup_instance(sample)` | Get the handle for a key value |
| `get_key_value(handle)` | Recover the key from a handle (useful when a notification has no data) |
| `read` / `take` with an instance handle | Read only that instance's samples |
| `read_next_instance` / `take_next_instance` | Iterate across instances in handle order |

Instance handles are local identifiers: use them within a process, not across the network (see also topic 19 on GUIDs).

## An Analogy That Maps Well

A topic is a **spreadsheet with a defined set of columns**. The **key** is the row ID column. An **instance** is one **row**. A **sample** is what that row contained at one moment. The DataWriter edits rows and the DataReader reads them. History decides how many earlier versions of each row are kept.

## Summary

An instance is the persistent identity of one logical thing, defined by the key fields. Samples are its successive states. DDS applies history, deadline, ownership and lifecycle per instance, which is what lets one topic carry thousands of independent entities.

## Things to Remember

- **Instance = identity (key value); Sample = state at a moment.**
- **Keys are declared in the type** with `@key`, not by a QoS setting.
- **Non-keyed topics have one instance.**
- **History, Deadline, Ownership, Time-Based Filter and Lifespan act per instance.**
- **`dispose()` means "this thing no longer exists"; silence does not.**
- **Instance handles are local**; do not send them over the network.
