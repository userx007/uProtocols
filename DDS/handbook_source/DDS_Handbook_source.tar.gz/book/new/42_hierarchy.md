# 42. The DDS Entity Hierarchy Illustrated {#ch42}

## Overview

This chapter puts the entities of chapters 2 to 5 into one picture, with the isolation boundaries marked.

![Domain, participant, topic, publisher, subscriber, writer, reader](img/hierarchy.png){width=90%}

## Reading the Picture

1. **Domain ID** is the highest isolation layer. Only participants with the same Domain ID can discover each other. Nothing crosses a domain boundary unless a bridge such as a Routing Service republishes it.
2. **DomainParticipant** is the application's membership of one domain and the factory for all other entities.
3. **Topic** is the schema (name plus type) that writers and readers share.
4. **Publisher and Subscriber** group writers and readers and carry **Partition** and **Presentation** QoS.
5. **DataWriter and DataReader** are the endpoints that move samples.

## Domains Versus Partitions

![Domains are hard walls; partitions are soft filters inside a domain](img/domains_partitions.png){width=80%}

Two entities must be in the **same domain** before partitions even matter. Inside a domain:

- A writer and reader match only if the **partition names of their Publisher and Subscriber overlap**. Wildcards such as `*` are allowed.
- The **default partition is the empty string**. Two entities that both use the default match each other. An entity left at the default does *not* match one that sets a non-empty partition, unless that partition list also contains the empty string or a wildcard.
- A subscriber that wants to see everything can use the wildcard `*`.

::: warning
A common misconception is that the default (empty) partition matches all partitions. It does not. It matches other default-partition entities. To observe every partition, use a wildcard.
:::

## Matching in Four Steps

1. Same **Domain ID**.
2. Same **topic name** and compatible **type**.
3. Overlapping **partitions**.
4. Compatible **QoS** (offered at least requested for most policies), and permitted by **security**, if enabled.

If any step fails the pair does not match, and no data flows between those two endpoints.

## Summary

Domains are hard walls and partitions are soft filters inside a domain. The entity tree is Domain, then DomainParticipant, then Topic plus Publisher/Subscriber, then DataWriter/DataReader. Matching checks domain, topic and type, partition, QoS and security, in that order.

## Things to Remember

- **Domain = hard isolation**; **Partition = soft, runtime-changeable filter** inside a domain.
- **The default partition (empty string) matches only other default-partition entities**, not everything.
- **Use a wildcard partition** for monitoring tools that must see all partitions.
- **Four-step match**: domain, topic and type, partition, QoS (and security).
