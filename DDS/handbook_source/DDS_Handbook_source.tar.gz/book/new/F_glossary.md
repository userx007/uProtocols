# Appendix F: Glossary of DDS Terms {#appF}

Terms are in alphabetical order. A chapter number in brackets shows where to read more.

**ACKNACK**
: RTPS submessage sent by a reliable reader. It acknowledges what has been received and names missing sequence numbers. [18]

**Appendable**
: XTypes extensibility kind. New members may be added at the end of a type. [26]

**Authentication**
: Proving identity to other participants, using certificates signed by a trusted authority. [32]

**Best effort**
: Reliability kind with no retransmission. [7]

**Built-in topics**
: Standard topics (`DCPSParticipant`, `DCPSPublication`, `DCPSSubscription`) that describe the domain's discovered entities. [3, 36]

**CDR**
: Common Data Representation, the standard binary encoding of samples. [25]

**ContentFilteredTopic**
: A view of a topic that delivers only samples matching a filter expression. [35]

**Coherent access**
: Presentation setting that makes related changes visible to readers as one unit. [4]

**Deadline**
: Per-instance promise and expectation of a maximum time between updates. [10]

**Destination order**
: Whether samples are ordered by reception time or by source timestamp.

**Discovery**
: The process by which participants and endpoints find and match each other. [20 to 22]

**Dispose**
: A writer's explicit statement that an instance no longer exists. [5, 24]

**Domain**
: A logical network of participants sharing a Domain ID. Different domains are isolated. [2]

**DomainParticipant**
: An application's membership in a domain and the factory for all other entities. [2]

**DataReader**
: The endpoint that receives samples for one topic. [5]

**DataWriter**
: The endpoint that publishes samples for one topic. [5]

**Durability**
: QoS controlling whether late joiners receive earlier samples. [8]

**Endpoint**
: An RTPS writer or reader.

**Entity ID**
: The 4-byte part of a GUID that identifies an entity within a participant. [19]

**Exclusive ownership**
: Only the strongest live writer of an instance is delivered. [12]

**Final**
: XTypes extensibility kind. The type never changes. [26]

**GAP**
: RTPS submessage stating that certain sequence numbers will never be sent. [17, 18]

**GUID**
: 16-byte globally unique identifier: 12-byte participant prefix plus 4-byte entity ID. [19]

**Heartbeat**
: RTPS submessage from a reliable writer announcing the range of available sequence numbers. [18]

**History**
: QoS controlling how many samples are kept per instance. [9]

**IDL**
: Interface Definition Language, used to define data types. [23]

**IGMP**
: Protocol hosts use to join IPv4 multicast groups. [Appendix D]

**Instance**
: One logical thing identified by a key value. [24, 43]

**Instance handle**
: A local identifier for an instance. Not a GUID. [19, 43]

**Instance state**
: `ALIVE`, `NOT_ALIVE_DISPOSED` or `NOT_ALIVE_NO_WRITERS`. [24]

**Key**
: The fields of a type, marked `@key`, that identify an instance. [24]

**Late joiner**
: A reader that matches after samples were published. [8]

**Lease duration**
: Maximum time an entity may stay silent before it is considered not alive. [11, 20]

**Lifespan**
: QoS that expires samples after a duration. [14]

**Liveliness**
: QoS describing how a writer proves it is still alive. [11]

**Locator**
: A network address and port at which an endpoint can be reached. [20]

**Match**
: The state in which a writer and a reader are connected because their topic, type, QoS, partition and security are compatible. [5, 15]

**Multicast**
: One-to-many network delivery to a group. [28, Appendix D]

**MultiTopic**
: A derived topic that joins data from several topics. [35]

**Mutable (QoS)**
: A QoS policy that can be changed after creation. [6]

**Mutable (XTypes)**
: Extensibility kind where every member has an ID, allowing members to be added or reordered. [26]

**Offered / requested**
: A writer offers a level of service; a reader requests a level. They match when the offer satisfies the request. [6, 15]

**Ownership**
: QoS defining whether multiple writers may update the same instance (`SHARED`) or only one (`EXCLUSIVE`). [12]

**Participant**
: See DomainParticipant.

**Partition**
: String labels on Publisher or Subscriber that must overlap for entities to match. [13]

**Persistent**
: Durability kind backed by disk storage in a durability service. [8]

**Presentation**
: Publisher/Subscriber QoS controlling coherent and ordered access. [4]

**Publisher**
: Container that owns DataWriters. [4]

**QoS**
: Quality of Service: a set of policies that define how data is delivered. [6]

**Reliable**
: Reliability kind with retransmission of lost samples. [7]

**Resource limits**
: Hard caps on samples, instances and samples per instance. [9]

**RTPS**
: Real-Time Publish-Subscribe, the interoperable wire protocol. [16]

**Sample**
: One update of an instance's state. [24, 43]

**Sample info**
: Metadata delivered with each sample: states, timestamps, instance handle.

**Sequence number**
: Per-writer counter assigned to every sample. [18]

**SEDP**
: Simple Endpoint Discovery Protocol. [21]

**Shared memory transport**
: Transport for endpoints on the same host that bypasses the network stack. [27]

**SPDP**
: Simple Participant Discovery Protocol. [20]

**Status condition**
: Condition object used with WaitSets to react to entity status changes. [5]

**Subscriber**
: Container that owns DataReaders. [4]

**Submessage**
: A unit inside an RTPS message, such as DATA or HEARTBEAT. [17]

**Take / Read**
: `take()` returns samples and removes them from the reader cache; `read()` leaves them. [5]

**Time-based filter**
: Reader QoS limiting delivery to one sample per instance per interval. [14]

**Topic**
: A named, typed channel: name plus type plus QoS. [3]

**Transient**
: Durability kind where a separate service keeps data in memory. [8]

**Transient local**
: Durability kind where the writer keeps data for late joiners. [8]

**Type object**
: XTypes description of a type, exchanged at discovery for compatibility checks. [26]

**Unicast**
: One-to-one network delivery. [28, Appendix D]

**Volatile**
: Durability kind that keeps nothing for late joiners. [8]

**WaitSet**
: Mechanism that blocks a thread until one of its attached conditions is true. [5]

**XCDR**
: Versions of CDR used with XTypes (XCDR1, XCDR2). [25]

**XTypes**
: The Extensible and Dynamic Topic Types specification. [26]
