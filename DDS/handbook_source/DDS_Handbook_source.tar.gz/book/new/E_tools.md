# Appendix E: Tools for Tracing, Decoding and Debugging {#appE}

## Wireshark and tshark

Wireshark has a built-in RTPS dissector. It decodes headers, submessages, GUIDs, sequence numbers and (for many types) the serialized payload.

```bash
# capture the default discovery range
tcpdump -i eth0 -w dds.pcap \
    'udp portrange 7400-7500'

# read it, RTPS only
tshark -r dds.pcap -Y rtps

# only HEARTBEAT and ACKNACK exchanges
tshark -r dds.pcap -Y \
    'rtps.sm.id == 0x07 || rtps.sm.id == 0x06'
```

Remember to capture on the right interface: `lo` for same-host UDP traffic. Shared-memory data never appears on any interface (topic 40). Display filter field names can vary slightly by Wireshark version.

## Vendor Tools

Tool names and availability vary by vendor and release. Check your installation.

| Stack | Typical tools |
|---|---|
| RTI Connext | Admin Console, Monitor, `rtiddsspy` for subscribing to data, `rtiddsping` for connectivity checks |
| eProsima Fast DDS | `fastdds` command-line tool (discovery server, shared-memory maintenance, XML validation), Fast DDS Spy and Monitor |
| Eclipse Cyclone DDS | `cyclonedds` command-line tool (listing, subscribing, type information in recent versions), `ddsperf` for performance tests |
| ROS 2 | `ros2 topic list`, `ros2 topic info --verbose` (shows the QoS of each endpoint), `ros2 topic echo`, `ros2 doctor` |

`ros2 topic info /name --verbose` is the fastest way to compare publisher and subscriber QoS when two ROS 2 nodes do not connect.

## Built-in Topics

Every DDS implementation exposes `DCPSParticipant`, `DCPSPublication` and `DCPSSubscription`. A short program that reads these gives you a live inventory of the domain with no extra tooling (topic 36).

## Decoding RTPS by Hand

The RTPS header is 20 bytes: the ASCII text `RTPS`, a 2-byte version, a 2-byte vendor ID and a 12-byte GUID prefix. Each submessage starts with a 4-byte header: `id` (1 byte), `flags` (1 byte, bit 0 is the endianness flag) and `length` (2 bytes).

Submessage IDs you will see most often:

| ID | Submessage |
|---|---|
| 0x01 | PAD |
| 0x06 | ACKNACK |
| 0x07 | HEARTBEAT |
| 0x08 | GAP |
| 0x09 | INFO_TS |
| 0x0c | INFO_SRC |
| 0x0e | INFO_DST |
| 0x12 | NACK_FRAG |
| 0x13 | HEARTBEAT_FRAG |
| 0x15 | DATA |
| 0x16 | DATA_FRAG |

A minimal walker over one packet, tested against a synthetic message:

```python
import struct
NAMES = {0x01:"PAD",0x06:"ACKNACK",0x07:"HEARTBEAT",0x08:"GAP",
 0x09:"INFO_TS",0x0c:"INFO_SRC",0x0d:"INFO_REPLY_IP4",
 0x0e:"INFO_DST",0x0f:"INFO_REPLY",0x12:"NACK_FRAG",
 0x13:"HEARTBEAT_FRAG",0x15:"DATA",0x16:"DATA_FRAG"}

def decode(pkt: bytes):
    if pkt[:4] != b"RTPS":
        raise ValueError("not an RTPS packet")
    ver = (pkt[4], pkt[5])
    vendor = pkt[6:8].hex()
    prefix = pkt[8:20].hex()
    print(f"RTPS {ver[0]}.{ver[1]} vendor=0x{vendor} "
          f"prefix={prefix}")
    off = 20
    while off + 4 <= len(pkt):
        sid, flags = pkt[off], pkt[off + 1]
        little = bool(flags & 0x01)       # E flag
        fmt = "<H" if little else ">H"
        (length,) = struct.unpack_from(fmt, pkt, off + 2)
        if length == 0:                   # runs to end of packet
            length = len(pkt) - off - 4
        name = NAMES.get(sid, f"UNKNOWN(0x{sid:02x})")
        print(f"  {name:<14} flags=0x{flags:02x} len={length}")
        off += 4 + length
```

This only lists the submessages. Decoding a `DATA` payload requires the sample's type, because the CDR encoding contains no field names (topic 25). For full payload decoding, use Wireshark, which can use type information from discovery in many cases, or your vendor's own tools.

## Things to Remember

- **Capture on the right interface** and filter with `rtps`.
- **HEARTBEAT / ACKNACK patterns reveal loss and tuning problems.**
- **`ros2 topic info --verbose`** compares endpoint QoS in one command.
- **Built-in topics give a free inventory** of every writer and reader.
- **RTPS submessages are length-prefixed**, so a decoder can skip what it does not know.
