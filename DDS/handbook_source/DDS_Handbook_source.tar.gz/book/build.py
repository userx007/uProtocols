import re, os, glob, shutil, subprocess, textwrap
import sys; sys.path.insert(0,'/home/claude')
import wraplib
from analogies import A, PARTS, PART_OF

SRC = "/home/claude/DDS/docs"
NEW = "/home/claude/book/new"
OUT = os.environ.get("OUTDIR", "/home/claude/book/build")
WRAP = int(os.environ.get("WRAPW", "58"))
shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)
shutil.copytree("/home/claude/book/img", OUT + "/img", ignore=shutil.ignore_patterns("*.dot"))

TITLES = {}
def chap_files():
    d = {}
    for f in glob.glob(SRC + "/[0-9][0-9]_*.md"):
        n = int(os.path.basename(f)[:2])
        if n <= 38: d[n] = f
    for n, name in [(39,"39_atlas.md"),(40,"40_flow.md"),(41,"41_config.md"),(42,"42_hierarchy.md"),(43,"43_instance.md")]:
        d[n] = NEW + "/" + name
    return d

# ---------- factual fixes on source chapters (regex with flexible whitespace) ----------
def flex(s):
    return r"\s+".join(re.escape(w) for w in s.split())
FIXES = {
 7: [
  (flex("- This is the **default** for `DataReaderQos`/`DataWriterQos` in most implementations — always check/set explicitly rather than assuming."),
   "- Specification defaults: `BEST_EFFORT` for DataReaders and `RELIABLE` for DataWriters. ROS 2 sets both to reliable by default. Vendors and frameworks differ, so always set it explicitly rather than assuming."),
  (flex("while the writer is left at its `BEST_EFFORT` default"), "while the writer is (by default or by mistake) `BEST_EFFORT`"),
 ],
 16: [
  (flex("(2008, as part of DDS 1.2's interoperability annex, later split into its own spec)"),
   "(in the mid-2000s, later published as its own specification)"),
 ],
 18: [
  (r"ACKNACK: readerSNState = \{ base = 105.*?encoding\)\.\"",
   'ACKNACK: base = 106, bitmap = 0b1\n  -> "I have everything below 106, and sample 106\n     itself is missing."'),
 ],
 27: [
  (flex("Most vendors will automatically prefer SHMEM"),
   "Several vendors (check yours; Eclipse Cyclone DDS needs its Iceoryx integration and explicit configuration) will automatically prefer SHMEM"),
 ],
 43: [],
}
# image replacements for box-drawing code blocks: chapter -> list of (marker inside block, image, caption)
IMG_BLOCKS = {
 16: [("Application code", "layers", "DDS sits above RTPS, which sits above the transport", 70)],
 19: [("GUID Prefix (12 bytes)", "guid", "Structure of a GUID", 70)],
 18: [("Time →", "heartbeat", "A lost sample is detected and repaired (HEARTBEAT, ACKNACK, retransmission)", 90)],
}

def convert_boxchars(code):
    rep = {"─":"-","│":"|","├":"+","└":"+","┌":"+","┐":"+","┘":"+","┤":"+","┬":"+","┴":"+","▼":"v","→":"->","—":"-","≤":"<=","≥":">=","°":" deg","–":"-"}
    for k,v in rep.items(): code = code.replace(k,v)
    return code

def wrap_code_line(line, lang, width=WRAP):
    if len(line) <= width: return [line]
    indent = len(line) - len(line.lstrip())
    s = line.strip()
    pre = " " * indent
    # comment lines: re-wrap with same marker
    m = re.match(r"^(//+|#+|--|\*)\s?", s)
    if m and not s.startswith("#include") and not s.startswith("#!"):
        marker = m.group(0)
        body = s[len(marker):]
        lines = textwrap.wrap(body, width - indent - len(marker), break_long_words=False)
        return [pre + marker + l for l in lines] or [line]
    if lang in ("bash","sh","shell"):
        out=[]; cur=line
        while len(cur) > width:
            cut = cur.rfind(" ", 0, width-2)
            if cut <= indent: break
            out.append(cur[:cut] + " \\")
            cur = pre + "    " + cur[cut+1:].lstrip()
        out.append(cur); return out
    out=[]; cur=line; cont = pre + "    "
    guard = 0
    while len(cur) > width and guard < 20:
        guard += 1
        seg = cur[:width]
        cut = max(seg.rfind(", "), seg.rfind(" "), seg.rfind("(")+1)
        if seg.rfind(", ") > 0 and seg.rfind(", ") >= cut - 12: cut = seg.rfind(", ") + 1
        if cut <= len(cur) - len(cur.lstrip()) + 4: break
        out.append(cur[:cut].rstrip())
        cur = cont + cur[cut:].lstrip()
    out.append(cur); return out

def wrap_code_line(line, lang, width=WRAP):
    return wraplib.wrap_line(line, lang)

def process_code_blocks(text, ch):
    imgs = list(IMG_BLOCKS.get(ch, []))
    def repl(m):
        lang, code = m.group(1), m.group(2)
        for marker, name, cap, w in imgs:
            if marker in code:
                return f"![{cap}](img/{name}.png){{width={w}%}}\n"
        code = convert_boxchars(code)
        lines=[]
        for l in code.rstrip("\n").split("\n"):
            lines.extend(wrap_code_line(l.rstrip(), lang))
        lang = "" if lang in ("ascii","text") else lang
        return "```" + lang + "\n" + "\n".join(lines) + "\n```"
    return re.sub(r"```([A-Za-z0-9_+-]*)\n(.*?)```", repl, text, flags=re.S)

# ---------- tables -> cards when too wide ----------
def split_row(line):
    line = line.strip()
    if line.startswith("|"): line = line[1:]
    if line.endswith("|"): line = line[:-1]
    cells=[]; cur=""; tick=False
    for ch in line:
        if ch == "`": tick = not tick
        if ch == "|" and not tick:
            cells.append(cur.strip()); cur=""
        else: cur += ch
    cells.append(cur.strip()); return cells

def convert_tables(text):
    lines = text.split("\n"); out=[]; i=0; in_code=False
    while i < len(lines):
        l = lines[i]
        if l.startswith("```"): in_code = not in_code
        if (not in_code and l.strip().startswith("|") and i+1 < len(lines)
            and re.match(r"^\s*\|?\s*:?-{2,}", lines[i+1])):
            j = i; tbl=[]
            while j < len(lines) and lines[j].strip().startswith("|"):
                tbl.append(lines[j]); j += 1
            header = split_row(tbl[0]); rows = [split_row(r) for r in tbl[2:]]
            n = len(header); maxc = max((len(c) for r in rows for c in r), default=0)
            rowlen = max((sum(len(c) for c in r) for r in rows), default=0)
            header = [h.replace("*","").replace("`","") for h in header]
            if (n >= 4 and rowlen > 90) or (n == 3 and (maxc > 130 or rowlen > 230)) or (n == 2 and maxc > 220):
                out.append("")
                for r in rows:
                    r += [""]*(n-len(r))
                    out.append(f"**{r[0]}**")
                    out.append("")
                    for k in range(1, n):
                        if r[k]: out.append(f"- *{header[k]}:* {r[k]}")
                    out.append("")
            else:
                out.extend(tbl)
            i = j; continue
        out.append(l); i += 1
    return "\n".join(out)

# ---------- cross-reference links ----------
def link_topics(text):
    out=[]; in_code=False
    for l in text.split("\n"):
        if l.startswith("```"): in_code = not in_code
        if in_code or l.startswith("#") or l.startswith("!["):
            out.append(l); continue
        def rep(m):
            seq = m.group(2)
            seq = re.sub(r"\b(\d{2})\b", lambda k: f"[{k.group(1)}](#ch{k.group(1)})", seq)
            return m.group(1) + " " + seq
        l = re.sub(r"\b([Tt]opics?)\s+((?:\d{2})(?:\s*(?:–|-|/|,|and|to)\s*\d{2})*)", rep, l)
        out.append(l)
    return "\n".join(out)

def clean_text(t):
    t = t.replace("✅ ","").replace("❌ ","").replace("↔"," with ")
    t = t.replace("\u200b","")
    return t

def box(n):
    one, ana = A[n]
    return ("\n::: keybox\n**In one sentence.** " + one + "\n:::\n\n::: analogy\n**Analogy.** " + ana + "\n:::\n\n")

def prep_chapter(n, path):
    t = open(path, encoding="utf-8").read()
    if n == 43:
        t = re.sub(r"## An Analogy That Maps Well.*?(?=## Summary)", "", t, flags=re.S)
    for pat, rep in FIXES.get(n, []):
        t2 = re.sub(pat, rep, t, flags=re.S)
        if t2 == t: print("WARN: fix not applied in ch", n, pat[:40])
        t = t2
    t = clean_text(t)
    # headings
    t = re.sub(r"^## (Key Takeaways|Things to Remember)\s*$", "## Things to Remember", t, flags=re.M)
    m = re.match(r"# (\d+)\.\s*(.*?)\s*(\{#ch\d+\})?\s*\n", t)
    title = m.group(2)
    TITLES[n] = title
    t = t.replace(m.group(0), f"# {n:02d}. {title} {{#ch{n:02d}}}\n" + box(n), 1)
    t = process_code_blocks(t, n)
    t = convert_tables(t)
    t = link_topics(t)
    return t

def extract_bullets(t):
    m = re.search(r"## Things to Remember\s*\n(.*?)(?=\n## |\Z)", t, flags=re.S)
    return m.group(1).strip() if m else ""

def main():
    files = chap_files()
    chapters = {}; bullets = {}
    for n in sorted(files):
        chapters[n] = prep_chapter(n, files[n])
        bullets[n] = extract_bullets(chapters[n])
    parts_out = []
    parts_out.append(("00_preface", open(NEW+"/00_preface.md").read()))
    parts_out.append(("00b_big", open(NEW+"/00b_mental_model.md").read()))
    roman = {1:"I",2:"II",3:"III",4:"IV",5:"V",6:"VI",7:"VII",8:"VIII",9:"IX"}
    seen=set()
    for n in sorted(chapters):
        p = PART_OF[n]
        if p not in seen:
            seen.add(p)
            title, blurb, intro = PARTS[p]
            parts_out.append((f"part{p}", f"# {title} {{#part{p} .unnumbered .part}}\n\n*{blurb}*\n\n{intro}\n"))
        parts_out.append((f"ch{n:02d}", chapters[n]))
    # Appendix A refresher
    ra = ["# Appendix A: The Refresher {#appA}\n",
          "Every chapter's *Things to Remember*, in chapter order. Read this when you need a fast refresh of the whole subject. Tap a chapter title to jump to the full explanation.\n"]
    for p in range(1,10):
        ra.append(f"\n## {PARTS[p][0]}\n")
        for n in sorted(k for k in chapters if PART_OF[k]==p):
            if not bullets[n]: continue
            ra.append(f"\n**[{n:02d}. {TITLES[n]}](#ch{n:02d})**\n")
            ra.append(bullets[n] + "\n")
    parts_out.append(("appA", "\n".join(ra)))
    for name in ["B_cheatsheets","C_trouble","D_network","E_tools","F_glossary"]:
        t = open(f"{NEW}/{name}.md").read()
        t = process_code_blocks(clean_text(t), 0)
        t = convert_tables(t)
        parts_out.append((name, t))
    for i,(name,text) in enumerate(parts_out):
        open(f"{OUT}/{i:03d}_{name}.md","w").write(text.rstrip()+"\n\n")
    print("chapters:", len(chapters), "files:", len(parts_out))

main()
