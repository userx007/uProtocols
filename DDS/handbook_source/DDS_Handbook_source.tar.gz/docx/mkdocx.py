import sys, os, re, glob, subprocess
name, bookdir, script, outname = sys.argv[1:5]
build = f"{bookdir}/build_docx"
env = dict(os.environ, OUTDIR=build, WRAPW="86")
subprocess.run(["python3", script], cwd=bookdir, env=env, check=True)
# contents page
lines = ["# Contents {#contents .unnumbered}\n", "Tap an entry to jump to it. In Word, the Navigation Pane (View, Navigation Pane) shows every chapter and section.\n"]
files = sorted(f for f in glob.glob(build + "/*.md"))
cur_list = []
def flush():
    global cur_list
    if cur_list: lines.append("\n".join(cur_list) + "\n"); cur_list = []
for f in files:
    first = open(f).readline().strip()
    m = re.match(r"# (.*?)\s*\{#([\w-]+)([^}]*)\}", first)
    if not m: continue
    title, ident, rest = m.groups()
    if ".part" in rest:
        flush(); lines.append(f"\n**[{title}](#{ident})**\n")
    else:
        cur_list.append(f"- [{title}](#{ident})")
flush()
open(build + "/001_zcontents.md", "w").write("\n".join(lines))
meta = f"{bookdir}/meta.yaml"
md = sorted(glob.glob(build + "/*.md"))
out = f"/home/claude/docx/{outname}"
cmd = ["pandoc", meta] + md + ["-f", "markdown+definition_lists+fenced_divs+pipe_tables+lists_without_preceding_blankline", "-t", "docx",
       "--reference-doc=/home/claude/docx/ref.docx", "--lua-filter=/home/claude/docx/filter.lua",
       f"--resource-path={build}", "-o", out]
subprocess.run(cmd, check=True)
print("wrote", out, os.path.getsize(out))
