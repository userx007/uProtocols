import subprocess, copy
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

subprocess.run("pandoc -o ref0.docx --print-default-data-file reference.docx", shell=True, check=True)
d = Document("ref0.docx")
BODY, MONO = "Calibri", "Courier New"

def setfont(style, name, size=None, bold=None, italic=None, color=None):
    f = style.font; f.name = name
    rpr = style.element.get_or_add_rPr()
    rf = rpr.find(qn('w:rFonts'))
    if rf is None: rf = OxmlElement('w:rFonts'); rpr.append(rf)
    for a in ('w:ascii','w:hAnsi','w:cs','w:eastAsia'): rf.set(qn(a), name)
    for a in ('w:asciiTheme','w:hAnsiTheme','w:cstheme','w:eastAsiaTheme'):
        if rf.get(qn(a)) is not None: del rf.attrib[qn(a)]
    if size: f.size = Pt(size)
    if bold is not None: f.bold = bold
    if italic is not None: f.italic = italic
    if color: f.color.rgb = RGBColor.from_string(color)

def border(ppr, sides, sz=8, color="444444", val="single", space=4):
    b = OxmlElement('w:pBdr')
    for s in sides:
        e = OxmlElement(f'w:{s}'); e.set(qn('w:val'), val); e.set(qn('w:sz'), str(sz)); e.set(qn('w:space'), str(space)); e.set(qn('w:color'), color); b.append(e)
    old = ppr.find(qn('w:pBdr'))
    if old is not None: ppr.remove(old)
    ppr.append(b)

def shade(ppr, fill):
    old = ppr.find(qn('w:shd'))
    if old is not None: ppr.remove(old)
    s = OxmlElement('w:shd'); s.set(qn('w:val'), 'clear'); s.set(qn('w:color'), 'auto'); s.set(qn('w:fill'), fill); ppr.append(s)

st = d.styles
def get(name):
    for x in st:
        if x.name == name: return x
    return None

n = get('Normal'); setfont(n, BODY, 10.5); n.paragraph_format.space_after = Pt(6); n.paragraph_format.line_spacing = 1.15
for nm in ('Body Text','First Paragraph','Compact'):
    s = get(nm)
    if s is not None:
        setfont(s, BODY, 10.5); s.paragraph_format.space_after = Pt(6 if nm != 'Compact' else 2); s.paragraph_format.space_before = Pt(0)
sizes = {'Heading 1':(22,"1F2937",18,10),'Heading 2':(15,"1F2937",16,6),'Heading 3':(12.5,"374151",12,4),'Heading 4':(11,"374151",10,3)}
for nm,(sz,col,bef,aft) in sizes.items():
    s = get(nm); setfont(s, BODY, sz, True, nm=='Heading 4', col)
    pf = s.paragraph_format; pf.space_before = Pt(bef); pf.space_after = Pt(aft); pf.keep_with_next = True; pf.keep_together = True
    if nm == 'Heading 1':
        pf.page_break_before = True
        border(s.element.get_or_add_pPr(), ['bottom'], 12, "1F2937", space=3)
    s.element.get_or_add_pPr()
for nm,sz,al,bf,col in [('Title',34,WD_ALIGN_PARAGRAPH.CENTER,150,"111827"),('Subtitle',15,WD_ALIGN_PARAGRAPH.CENTER,10,"374151"),('Author',12,WD_ALIGN_PARAGRAPH.CENTER,20,"374151"),('Date',11,WD_ALIGN_PARAGRAPH.CENTER,4,"6B7280")]:
    s = get(nm)
    if s is not None:
        setfont(s, BODY, sz, nm=='Title', None, col); s.paragraph_format.alignment = al; s.paragraph_format.space_before = Pt(bf); s.paragraph_format.space_after = Pt(8)
# code
sc = get('Source Code')
if sc is None: sc = st.add_style('Source Code', WD_STYLE_TYPE.PARAGRAPH)
sc.base_style = get('Normal')
setfont(sc, MONO, 8.5); sc.paragraph_format.space_before = Pt(4); sc.paragraph_format.space_after = Pt(8); sc.paragraph_format.line_spacing = 1.0
sc.paragraph_format.left_indent = Cm(0.2); sc.paragraph_format.right_indent = Cm(0.2)
ppr = sc.element.get_or_add_pPr(); shade(ppr, "F3F4F6"); border(ppr, ['top','left','bottom','right'], 4, "9CA3AF", space=4)
vc = get('Verbatim Char')
if vc is None: vc = st.add_style('Verbatim Char', WD_STYLE_TYPE.CHARACTER)
setfont(vc, MONO, 9.5)
# block quote, definition
for nm in ('Block Text',):
    s = get(nm)
    if s is not None: setfont(s, BODY, 10.5, None, True)
s = get('Definition Term')
if s is not None: setfont(s, BODY, 10.5, True); s.paragraph_format.space_before = Pt(6); s.paragraph_format.space_after = Pt(0); s.paragraph_format.keep_with_next = True
s = get('Definition')
if s is not None: setfont(s, BODY, 10.5); s.paragraph_format.left_indent = Cm(0.8)
for nm,al,sz,it in [('Captioned Figure',WD_ALIGN_PARAGRAPH.CENTER,10.5,False),('Image Caption',WD_ALIGN_PARAGRAPH.CENTER,9,True),('Figure',WD_ALIGN_PARAGRAPH.CENTER,10.5,False)]:
    s = get(nm)
    if s is not None:
        setfont(s, BODY, sz, None, it, "4B5563" if nm=='Image Caption' else None); s.paragraph_format.alignment = al; s.paragraph_format.space_after = Pt(8); s.paragraph_format.keep_with_next = (nm!='Image Caption')
s = get('Table Caption')
if s is not None: setfont(s, BODY, 9, None, True)
# callout styles
def callout(name, fill, sides, bsz, bcol, indent=0.2, val="single"):
    s = get(name) or st.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
    s.base_style = get('Normal'); setfont(s, BODY, 10.5)
    s.paragraph_format.space_before = Pt(6); s.paragraph_format.space_after = Pt(8); s.paragraph_format.left_indent = Cm(indent); s.paragraph_format.right_indent = Cm(0.2)
    ppr = s.element.get_or_add_pPr(); shade(ppr, fill); border(ppr, sides, bsz, bcol, val, space=6)
callout('Key Box', 'E5E7EB', ['top','left','bottom','right'], 12, "111827")
callout('Analogy', 'F3F4F6', ['left'], 36, "6B7280", indent=0.3)
callout('Editor Note', 'FFF7E6', ['top','left','bottom','right'], 8, "B45309", val="dashed")
# hyperlink color
h = get('Hyperlink')
if h is not None: setfont(h, BODY, None, None, None, "1D4ED8"); h.font.underline = False
# table style
ts = get('Table')
if ts is not None:
    tpr = ts.element.find(qn('w:tblPr'))
    if tpr is None: tpr = OxmlElement('w:tblPr'); ts.element.append(tpr)
    for old in tpr.findall(qn('w:tblBorders')): tpr.remove(old)
    b = OxmlElement('w:tblBorders')
    for side in ('top','left','bottom','right','insideH','insideV'):
        e = OxmlElement(f'w:{side}'); e.set(qn('w:val'),'single'); e.set(qn('w:sz'),'4'); e.set(qn('w:space'),'0'); e.set(qn('w:color'),'9CA3AF'); b.append(e)
    tpr.append(b)
    cm = OxmlElement('w:tblCellMar')
    for side,w in (('top',40),('left',90),('bottom',40),('right',90)):
        e = OxmlElement(f'w:{side}'); e.set(qn('w:w'),str(w)); e.set(qn('w:type'),'dxa'); cm.append(e)
    for old in tpr.findall(qn('w:tblCellMar')): tpr.remove(old)
    tpr.append(cm)
# page setup A4 + footer page numbers
sec = d.sections[0]
sec.page_width = Cm(21.0); sec.page_height = Cm(29.7)
sec.left_margin = sec.right_margin = Cm(2.2); sec.top_margin = Cm(2.2); sec.bottom_margin = Cm(2.2)
fp = sec.footer.paragraphs[0] if sec.footer.paragraphs else sec.footer.add_paragraph()
fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
def fld(p, instr):
    r = p.add_run(); r.font.size = Pt(9); r.font.name = BODY
    for t,txt in (('begin',None),('instr',instr),('separate',None),('text','1'),('end',None)):
        if t=='instr':
            e = OxmlElement('w:instrText'); e.set(qn('xml:space'),'preserve'); e.text = txt; r._r.append(e)
        elif t=='text':
            e = OxmlElement('w:t'); e.text = txt; r._r.append(e)
        else:
            e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'), t); r._r.append(e)
fld(fp, ' PAGE ')
d.save("ref.docx"); print("ref ok")
