local map = { keybox = "Key Box", analogy = "Analogy", warning = "Editor Note" }
function Div(el)
  for cls, sty in pairs(map) do
    if el.classes:includes(cls) then
      el.attributes['custom-style'] = sty
      return el
    end
  end
end
function Table(tbl)
  local n = #tbl.colspecs
  if n < 2 then return nil end
  local maxl = {}
  for i = 1, n do maxl[i] = 4 end
  local function scan(rows)
    for _, row in ipairs(rows) do
      for i, c in ipairs(row.cells) do
        local txt = pandoc.utils.stringify(c.contents)
        local eff = math.min(#txt, 60) + 3
        for w in txt:gmatch("%S+") do if #w + 3 > eff then eff = #w + 3 end end
        if eff < 9 then eff = 9 end
        if maxl[i] and eff > maxl[i] then maxl[i] = eff end
      end
    end
  end
  scan(tbl.head.rows)
  for _, b in ipairs(tbl.bodies) do scan(b.body) end
  local tot = 0
  for i = 1, n do tot = tot + maxl[i] end
  local specs = {}
  for i = 1, n do specs[i] = { tbl.colspecs[i][1], maxl[i] / tot } end
  tbl.colspecs = specs
  return tbl
end
