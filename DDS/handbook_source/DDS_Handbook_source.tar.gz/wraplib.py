import re, textwrap
import os
W = int(os.environ.get("WRAPW", "58"))
def _split_trailing(line):
    q = 0
    for i in range(len(line) - 1):
        ch = line[i]
        if ch == '"' and (i == 0 or line[i-1] != "\\"): q ^= 1
        if q == 0 and line[i:i+2] == "//" and i > 0 and line[i-1] != ":" and line[:i].strip():
            return line[:i].rstrip(), line[i:].strip()
    return line, None

# quote-aware wrapper for code lines
def wrap_line(line, lang):
    if len(line) <= W: return [line]
    indent = len(line) - len(line.lstrip()); s = line.strip(); pre = " " * indent
    if lang not in ("bash", "sh", "shell", "toml", "yaml", "python", "py"):
        code_part, cmt = _split_trailing(line)
        if cmt:
            import textwrap
            cl = [pre + "// " + c for c in textwrap.wrap(cmt.lstrip("/ ").strip(), max(20, W - indent - 3), break_long_words=False)]
            return cl + wrap_line(code_part, lang)
    m = re.match(r"^(//+!?|#+(?=\s)|--(?=\s)|\*(?=\s)|/\*+)\s?", s)
    if m and not s.startswith(("#include", "#define", "#if", "#endif", "#else", "#pragma", "#!", "#[")):
        marker = m.group(0); body = s[len(marker):]
        import textwrap
        ls = textwrap.wrap(body, max(20, W - indent - len(marker)), break_long_words=False)
        return [pre + marker + l for l in ls] or [line]
    if s.startswith(("#define", "#if", "#elif")) and "\\" not in s:
        out = []; cur = line
        while len(cur) > W:
            cut = cur.rfind(" ", 0, W - 2)
            if cut <= indent + 8: break
            out.append(cur[:cut] + " \\"); cur = pre + "    " + cur[cut+1:].lstrip()
        out.append(cur); return out
    if lang in ("bash", "sh", "shell"):
        out = []; cur = line
        while len(cur) > W:
            cut = cur.rfind(" ", 0, W - 2)
            if cut <= indent: break
            out.append(cur[:cut] + " \\"); cur = pre + "    " + cur[cut+1:].lstrip()
        out.append(cur); return out
    out = []; cur = line; cont = pre + "    "; guard = 0
    while len(cur) > W and guard < 30:
        guard += 1
        seg = cur[:W]; base = len(cur) - len(cur.lstrip())
        cands = []
        for i, ch in enumerate(seg):
            if i <= base + 4: continue
            if ch in " ," or ch == "(":
                if seg[:i+1].count('"') % 2 == 0:
                    cands.append(i + 1 if ch in ",(" else i)
        if not cands:
            # inside a string: cut at last space anyway, closing/opening quotes
            sp = seg.rfind(" ")
            if sp <= base + 4: break
            out.append(cur[:sp].rstrip() + '"'); cur = cont + '"' + cur[sp+1:].lstrip(); continue
        cut = max(cands)
        out.append(cur[:cut].rstrip()); cur = cont + cur[cut:].lstrip()
    out.append(cur); return out

