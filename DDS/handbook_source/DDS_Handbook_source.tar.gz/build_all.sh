#!/bin/bash
set -e
FROM="markdown+definition_lists+fenced_divs+pipe_tables+lists_without_preceding_blankline"
epub() { # dir builder epubname
  (cd /home/claude/$1 && WRAPW=58 OUTDIR=/home/claude/$1/build python3 $2 >/dev/null && cd build && pandoc ../meta.yaml $(ls *.md | sort) -f $FROM -t epub3 --toc --toc-depth=2 --split-level=1 --css=../style.css --epub-cover-image=../cover.png --no-highlight --resource-path=. -o ../$3)
}
epub book build.py DDS_Handbook.epub
epub mbook mbuild.py MQTT_Handbook.epub
epub obook obuild.py Modbus_Handbook.epub
cd /home/claude/docx
python3 mkdocx.py dds /home/claude/book build.py DDS_Handbook.docx
python3 mkdocx.py mqtt /home/claude/mbook mbuild.py MQTT_Handbook.docx
python3 mkdocx.py modbus /home/claude/obook obuild.py Modbus_Handbook.docx
ls -la /home/claude/book/DDS_Handbook.epub /home/claude/mbook/MQTT_Handbook.epub /home/claude/obook/Modbus_Handbook.epub /home/claude/docx/*.docx
