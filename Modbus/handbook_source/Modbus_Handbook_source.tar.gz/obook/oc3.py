from oc2 import C
C[61] = ("Modbus Gateway Architecture",
 "A gateway lets TCP clients reach serial slaves, using the unit ID as the serial address.",
 "An **interpreter at the border** between the Ethernet world and the serial world.",
 ["**TCP in, RS-485 out**: unit ID becomes slave address.","**One serial request at a time.**","**Queue requests from many clients.**","**Return exception 0A/0B** when the path or target fails.","**Size timeouts** for the slowest device."])
C[62] = ("RTU to TCP Conversion",
 "Conversion strips address and CRC and adds an MBAP header (or the reverse).",
 "**Re-addressing a letter** into a different kind of envelope without touching the message inside.",
 ["**RTU to TCP**: verify CRC, remove address and CRC, add MBAP.","**TCP to RTU**: remove MBAP, add address from unit ID, compute CRC.","**Keep a transaction map.**","**Preserve the PDU unchanged.**","**Handle timeouts on both sides.**"])
C[63] = ("Protocol Translation Patterns",
 "Common patterns: transparent proxy, cache, mapping layer.",
 "Different kinds of **translators**: word for word, summarising, or keeping a phrase book.",
 ["**Transparent**: forward frames as is.","**Cache**: serve reads from stored polls.","**Mapping**: remap addresses and types.","**Know your freshness requirements.**","**Document every transformation.**"])
C[64] = ("Address Mapping and Translation",
 "Mapping tables translate between external and device addresses.",
 "A **phone-book of aliases**.",
 ["**Table of external to internal address.**","**Mind one-based vs zero-based.**","**Preserve data types and scaling.**","**Validate ranges.**","**Version the map.**"])
C[65] = ("Multi-Protocol Gateway Implementation",
 "A gateway can serve Modbus, OPC UA, MQTT and others from shared data.",
 "A **multilingual front desk**.",
 ["**Central data model** feeds all protocol front-ends.","**Timestamps and quality** per value.","**Isolate protocol threads.**","**Config-driven mapping.**","**Secure each interface separately.**"])
C[66] = ("SCADA System Integration",
 "SCADA polls devices over Modbus, stores tags and raises alarms.",
 "A **control room** that reads all the gauges.",
 ["**Tag = device + table + address + type + scale.**","**Poll groups** with rates.","**Quality flags** on communication loss.","**Alarm and write verification.**","**Redundant links** for critical points."])
C[67] = ("PLC Communication",
 "PLCs act as Modbus masters or slaves; check mapping, byte order and cycle time.",
 "The **foreman** of the machine, who sometimes asks and sometimes answers.",
 ["**Check one-based address conventions.**","**Check word order** for 32-bit.","**PLC scan time** limits response speed.","**Use the vendor's Modbus function blocks.**","**Test with a simulator.**"])
C[68] = ("OPC UA Integration",
 "Expose Modbus data as OPC UA nodes with proper types, timestamps and quality.",
 "A **translator into a richer language** with labels and units.",
 ["**Map registers to typed nodes.**","**Source timestamp** from the poll.","**Status codes** for bad communication.","**Subscriptions** reduce load.","**Security** is provided by OPC UA."])
C[69] = ("MQTT Bridge",
 "A bridge polls Modbus and publishes values to MQTT topics, and optionally writes back commands.",
 "A **courier** carrying readings from the machine to the noticeboard.",
 ["**Publish on change or interval.**","**Topic per device and point.**","**Retain latest values** if useful.","**Write-back** needs authentication.","**Include timestamps.**"])
C[70] = ("Historian Database Integration",
 "Historians store polled values with timestamps for trends and reporting.",
 "A **logbook** for every gauge.",
 ["**Timestamp at the poll.**","**Deadband** to reduce volume.","**Buffer during database outages.**","**Quality** flags.","**Retention and downsampling.**"])
C[71] = ("Modbus TCP Security (TLS)",
 "Modbus/TCP Security wraps Modbus TCP in TLS with mutual authentication, on port 802.",
 "Putting the plain telegram **inside a sealed, signed envelope** and checking the sender's passport.",
 ["**Port 802** for secured Modbus TCP.","**Mutual TLS** with X.509 certificates.","**Role information** can be carried in a certificate extension.","**Same PDU inside TLS.**","**Plain port 502 remains unsecured.**"])
C[72] = ("UDP Transport Layer",
 "Modbus over UDP is not part of the Modbus specification; some products implement MBAP over UDP.",
 "A **postcard version** that works but is not in the official rulebook.",
 ["**Not standardised**, so check device support.","**No delivery guarantee**; add timeouts and retries.","**Match by transaction ID.**","**No security.**","**Prefer TCP** unless you have a reason."])
C[73] = ("Load Balancing and Redundancy",
 "Redundant gateways or servers improve availability; clients must fail over.",
 "**A spare tyre and a second driver.**",
 ["**Active/standby** pairs.","**Heartbeat** and failover.","**Keep register state in sync.**","**Clients reconnect to the survivor.**","**Test failover.**"])
C[74] = ("Virtual COM Port Tunneling",
 "Serial-over-Ethernet tunnels make a remote serial port appear local.",
 "A **very long extension cable**.",
 ["**Tunnels add latency** and jitter.","**t3.5 detection may break**; prefer a Modbus-aware gateway.","**Buffering** can merge frames.","**Security** must be added.","**Use only when software needs a COM port.**"])
C[75] = ("WebSocket Transport",
 "A gateway lets browser apps reach Modbus through WebSocket frames.",
 "A **window onto the plant** for web pages.",
 ["**Gateway translates** WebSocket to Modbus TCP.","**Use wss and authentication.**","**Limit to read-only** where possible.","**Rate-limit.**","**Not part of the Modbus standard.**"])
C[76] = ("RTOS Integration",
 "On an RTOS, use tasks, queues and timers for the Modbus stack.",
 "A **shift roster** with clear duties.",
 ["**Receive task, parser task, application task.**","**Queues between them.**","**Timer for t3.5.**","**Priorities** avoid starvation.","**Watch stack sizes.**"])
C[77] = ("Bare-Metal Implementation",
 "A main loop with interrupts and a state machine can run Modbus without an OS.",
 "**Doing everything yourself**, with no staff.",
 ["**ISR receives bytes**, timer detects frame end.","**State machine** in the main loop.","**Static buffers.**","**Avoid blocking.**","**Watchdog.**"])
C[78] = ("Interrupt-Driven Serial Communication",
 "Interrupts handle received and transmitted bytes without polling.",
 "A **doorbell** instead of checking the door.",
 ["**Short ISRs.**","**Ring buffers** between ISR and main code.","**Handle overrun and framing errors.**","**RS-485 direction switch** after the last stop bit.","**Disable interrupts only briefly.**"])
C[79] = ("DMA for Serial Transfers",
 "DMA moves bytes between memory and UART without CPU involvement.",
 "A **conveyor belt** that loads the truck while you do other work.",
 ["**Idle-line interrupt** marks frame end.","**Circular DMA** buffer.","**Cache coherency** on bigger MCUs.","**Transmit-complete** before releasing RS-485 driver.","**Fewer interrupts.**"])
C[80] = ("Hard Real-Time Constraints",
 "Meet deadlines through bounded execution and priority discipline.",
 "A **train timetable**: lateness has consequences.",
 ["**Bound worst-case time.**","**Avoid dynamic allocation.**","**Measure jitter.**","**Prioritise control over comms.**","**Fail safe on timeout.**"])
C[81] = ("Modbus in Smart Meters",
 "Meters expose energy and power values as registers, often as 32-bit values or floats.",
 "The **electricity meter's display**, made readable by machines.",
 ["**Check word order and scale.**","**Energy counters** are 32 or 64-bit.","**Read in blocks.**","**Time sync** may matter.","**Follow the meter's register map.**"])
C[82] = ("Power Quality Monitoring",
 "Harmonics, sags and swells are exposed as registers; polling speed limits what you can catch.",
 "A **heart monitor** for the grid.",
 ["**Use event registers** for sags and swells.","**Poll fast enough** for needed resolution.","**Timestamps** matter.","**Large register blocks.**","**Verify units.**"])
C[83] = ("Solar Inverter Communication",
 "Inverters publish power, voltage and status and accept limits via registers.",
 "The **dashboard of a solar plant**.",
 ["**Vendor maps differ.**","**Write limits carefully.**","**Night-time behaviour**: devices may go offline.","**Scale factors** are often separate registers.","**Follow grid-code requirements.**"])
C[84] = ("Battery Management Systems",
 "BMS data (voltage, current, state of charge, alarms) is read over Modbus.",
 "The **fuel gauge and warning lights** of a battery.",
 ["**Alarm bits** need prompt handling.","**Signed values** for current.","**Never bypass safety** through writes.","**Poll rate vs wear.**","**Check scaling.**"])
C[85] = ("Building Automation (BACnet Bridge)",
 "A gateway maps Modbus points to BACnet objects.",
 "A **translator between two building languages**.",
 ["**Point mapping table.**","**Type and unit mapping.**","**Polling vs COV.**","**Writes need priority arrays** on BACnet side.","**Test both sides.**"])
C[86] = ("Motor Drive Control",
 "Drives use control and status words plus setpoint registers.",
 "A **remote control for a motor**.",
 ["**Control word** bits start, stop, reset.","**Status word** shows state.","**Ramp setpoints.**","**Watchdog** stops the drive on lost comms.","**Safety functions** belong in hardware."])
C[87] = ("Temperature Controller Integration",
 "Controllers expose process value, setpoint and mode registers, usually scaled by 10.",
 "A **thermostat** you can talk to.",
 ["**Scale** is often tenths of a degree.","**Write to setpoint**, not the process value.","**EEPROM write limits** for setpoint changes.","**Alarm registers.**","**Check units.**"])
C[88] = ("Flow Meter and Totalizer",
 "Flow rate and totals are floats or 32-bit counters; totalizers must not be lost.",
 "A **water meter with a trip counter**.",
 ["**Totalizer reset** is a write.","**Word order** for floats.","**Poll for rate, read totals less often.**","**Detect rollover.**","**Units and scaling.**"])
C[89] = ("Weighing and Load Cell Systems",
 "Weight indicators return values with decimal points and status flags.",
 "A **shop scale** that reports to a computer.",
 ["**Stable-weight flag.**","**Tare and zero** commands.","**Decimal point register.**","**Averaging.**","**Legal-for-trade** rules may apply."])
C[90] = ("Environmental Monitoring",
 "Sensors for temperature, humidity and gases report scaled values at low rates.",
 "A **weather station network**.",
 ["**Slow polling is enough.**","**Calibration and offsets.**","**Handle sensor faults.**","**Log with timestamps.**","**Battery or loop-powered devices.**"])
C[91] = ("Modbus Simulator Development",
 "A simulator pretends to be a slave or master for development and tests.",
 "A **flight simulator** for devices.",
 ["**Configurable register maps.**","**Inject errors and delays.**","**Support RTU and TCP.**","**Record and replay.**","**Match real device quirks.**"])
C[92] = ("Fuzzing and Security Testing",
 "Send malformed frames to find crashes and logic errors.",
 "A **crash-test** for protocol stacks.",
 ["**Mutate valid frames.**","**Check length fields** and counts.","**Run against sanitizers.**","**Only test systems you own.**","**Fix and add regression tests.**"])
C[93] = ("Load Testing and Stress Testing",
 "Measure throughput and latency under many clients or fast polling.",
 "A **stress test of a bridge**.",
 ["**Ramp load gradually.**","**Measure latency percentiles.**","**Watch CPU and sockets.**","**Test reconnect storms.**","**Compare with serial limits.**"])
C[94] = ("Protocol Compliance Testing",
 "Check conformance against the Modbus specification and conformance classes.",
 "An **exam** against the rulebook.",
 ["**Test all supported function codes.**","**Test exceptions and limits.**","**Check address/quantity validation.**","**Check timing for RTU.**","**Use the Modbus Organization's guidance.**"])
C[95] = ("Hardware-in-the-Loop Testing",
 "Test software against real or emulated hardware in a loop.",
 "**Rehearsing with real props.**",
 ["**Real device or emulator.**","**Automate scenarios.**","**Fault injection.**","**Record results.**","**Keep a hardware inventory.**"])
C[96] = ("Modbus Specification Evolution",
 "Modbus grew from a 1979 Modicon protocol to TCP (1999) and an open standard maintained since 2004.",
 "A **family tree** of the protocol.",
 ["**1979** Modicon; **1999** Modbus/TCP; **2004** Modbus Organization.","**2006** serial line V1.02 and application protocol V1.1b era.","**2018** Modbus/TCP Security.","**User codes**: 65 to 72, 100 to 110.","**10 standard exception codes**."])
C[97] = ("IEC 61158 Compliance",
 "Modbus appears in international standards through IEC publications, but the practical compliance target is the Modbus Organization's specifications.",
 "**Recognition by a standards body** is not the same as passing an exam.",
 ["**Modbus is covered by IEC PAS 62030** and related profiles.","**Modbus/TCP is not IEC 61158 Type 18** (that is CC-Link).","**Practical conformance** is defined by the Modbus specifications and classes.","**Check which profile** a customer means.","**Document your supported function codes.**"])
C[98] = ("Device Profile Documentation",
 "Document register maps, types, scaling, access and quirks in a structured profile.",
 "A **manual that machines can read**.",
 ["**One row per register/point.**","**Type, scale, unit, access.**","**Word order and base address.**","**Exceptions and limits.**","**Version it.**"])
C[99] = ("Configuration File Formats",
 "Use YAML, JSON or TOML to describe devices, maps and polling.",
 "A **settings sheet** that keeps code and configuration apart.",
 ["**Validate on load.**","**Separate devices, maps, polling.**","**Comments and versions.**","**Secrets not in files.**","**Hot reload** with care."])
C[100] = ("Modbus Plus and Proprietary Extensions",
 "Modbus Plus is a proprietary token-passing network from Modicon (1 Mbps); other vendors added their own extensions.",
 "A **private motorway** next to the public road.",
 ["**Modbus Plus**: token passing, peer-to-peer, 1 Mbps, proprietary.","**Legacy** technology.","**Gateways** bridge it to Modbus TCP.","**Vendor extensions** break interoperability.","**Prefer standard function codes.**"])
