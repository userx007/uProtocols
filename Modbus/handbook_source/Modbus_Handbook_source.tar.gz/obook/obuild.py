import re, os, glob, shutil, subprocess
import blib
from parts import PARTS
import oc3
C = oc3.C
SRC = "/home/claude/modbus/Modbus/docs"; SRCCODE = ""
NEW = "/home/claude/obook/new"; OUT = os.environ.get("OUTDIR", "/home/claude/obook/build")
shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)
shutil.copytree("/home/claude/obook/img", OUT + "/img", ignore=shutil.ignore_patterns("*.dot"))
W = int(os.environ.get("WRAPW", "58"))


def _split_trailing(line):
    q = 0
    for i in range(len(line) - 1):
        ch = line[i]
        if ch == '"' and (i == 0 or line[i-1] != "\\"): q ^= 1
        if q == 0 and line[i:i+2] == "//" and i > 0 and line[i-1] != ":" and line[:i].strip():
            return line[:i].rstrip(), line[i:].strip()
    return line, None

# quote-aware wrapper for code lines
def wrap_line(line, lang):
    if len(line) <= W: return [line]
    indent = len(line) - len(line.lstrip()); s = line.strip(); pre = " " * indent
    if lang not in ("bash", "sh", "shell", "toml", "yaml", "python", "py"):
        code_part, cmt = _split_trailing(line)
        if cmt:
            import textwrap
            cl = [pre + "// " + c for c in textwrap.wrap(cmt.lstrip("/ ").strip(), max(20, W - indent - 3), break_long_words=False)]
            return cl + wrap_line(code_part, lang)
    m = re.match(r"^(//+!?|#+(?=\s)|--(?=\s)|\*(?=\s)|/\*+)\s?", s)
    if m and not s.startswith(("#include", "#define", "#if", "#endif", "#else", "#pragma", "#!", "#[")):
        marker = m.group(0); body = s[len(marker):]
        import textwrap
        ls = textwrap.wrap(body, max(20, W - indent - len(marker)), break_long_words=False)
        return [pre + marker + l for l in ls] or [line]
    if s.startswith(("#define", "#if", "#elif")) and "\\" not in s:
        out = []; cur = line
        while len(cur) > W:
            cut = cur.rfind(" ", 0, W - 2)
            if cut <= indent + 8: break
            out.append(cur[:cut] + " \\"); cur = pre + "    " + cur[cut+1:].lstrip()
        out.append(cur); return out
    if lang in ("bash", "sh", "shell"):
        out = []; cur = line
        while len(cur) > W:
            cut = cur.rfind(" ", 0, W - 2)
            if cut <= indent: break
            out.append(cur[:cut] + " \\"); cur = pre + "    " + cur[cut+1:].lstrip()
        out.append(cur); return out
    out = []; cur = line; cont = pre + "    "; guard = 0
    while len(cur) > W and guard < 30:
        guard += 1
        seg = cur[:W]; base = len(cur) - len(cur.lstrip())
        cands = []
        for i, ch in enumerate(seg):
            if i <= base + 4: continue
            if ch in " ," or ch == "(":
                if seg[:i+1].count('"') % 2 == 0:
                    cands.append(i + 1 if ch in ",(" else i)
        if not cands:
            # inside a string: cut at last space anyway, closing/opening quotes
            sp = seg.rfind(" ")
            if sp <= base + 4: break
            out.append(cur[:sp].rstrip() + '"'); cur = cont + '"' + cur[sp+1:].lstrip(); continue
        cut = max(cands)
        out.append(cur[:cut].rstrip()); cur = cont + cur[cut:].lstrip()
    out.append(cur); return out
blib.wrap_code_line = lambda line, lang, width=W: wrap_line(line, lang)

blib.IMG_BLOCKS = {
 1: [("┌─────", "frames", "The same PDU in three wrappers", 80)],
}
EXTRA = {1: ("reqresp", "Request, response and exception", 85), 4: ("mbap", "The MBAP header", 80),
          17: ("rs485", "RS-485 daisy chain with terminators", 55), 21: ("timing", "RTU frame spacing", 90),
          37: ("datamodel", "The four data tables", 70), 61: ("gateway", "A Modbus gateway", 80)}
NOTES = {
 17: "A and B terminals are labelled inconsistently between manufacturers. If a bus does not work, swapping the two wires is a legitimate test. Idle polarity: the non-inverting line (B, D1) must be above the inverting line (A, D0).",
 18: "The Modbus serial-line specification defaults to 8 data bits, **even parity**, 1 stop bit (8E1), so that characters are 11 bits long. 8N2 is the allowed no-parity form. 8N1 (10 bits) is widely used but does not follow the specification, and the 3.5-character timing then differs slightly.",
 29: "In the code listings the names follow each chapter's own labels. Use Appendix B.7 for the standard meaning of ABCD, CDAB, BADC and DCBA.",
 30: "CDAB is a pure word swap: the two registers are exchanged but the bytes inside each register stay in order.",
 31: "Word order of floats is a **device** decision, not defined by Modbus. Test with a known value before trusting any convention.",
 51: "Function codes 0x07, 0x08, 0x0B, 0x0C and 0x11 are defined for **serial lines only**. Do not expect them on Modbus TCP devices.",
 52: "The table lists the common sub-functions. The specification also defines 0x0010 (server NAK count), 0x0011 (server busy count), 0x0012 (bus character overrun count) and 0x0014 (clear overrun counter and flag).",
 53: "The status word is **0xFFFF** while a program command is still being processed and **0x0000** otherwise. The listings below use bit 0x8000 as a busy flag; a test for 0xFFFF is the specification-correct form.",
 54: "The status word is **0xFFFF** or **0x0000**, as in function 0x0B. The listings below model it as flag bits, which is a simplification.",
 71: "Secured Modbus/TCP is a Modbus Organization specification that uses **TCP port 802** with mutual TLS. Examples that use other ports are lab examples.",
 72: "Modbus over UDP is **not** part of the Modbus specification. Some products implement it, so check device documentation before relying on it.",
 42: "The CRC lookup table in the original text was truncated, so the code could not produce correct CRCs. This edition contains the complete 256-entry table.",
 45: "The CRC lookup table in the original text was truncated, so the C code could not produce correct CRCs. This edition contains the complete 256-entry table.",
 97: "Modbus TCP is **not** IEC 61158 Type 18 (that is CC-Link). Modbus is referenced through IEC PAS 62030 and IEC 61784 profiles. This edition corrects the original statements.",
}
TEXTFIX = {
 1: [(r"The Modbus protocol was created by Dick Morley and the Modicon team to enable communication", "The Modbus protocol was created at Modicon to enable communication")],
 3: [(r":1103E8000275", ":110303E80002FF"), (r"- `75` - LRC checksum", "- `FF` - LRC checksum")],
 17: [(r"- Pull line A high and line B low during idle states", "- Keep the non-inverting line (B, D1) above the inverting line (A, D0) when idle (A/B labels differ between vendors)"),
      (r"- Pull-up resistor: Connect A line to \+5V through 560-680Ω", "- Pull-up resistor: connect the non-inverting line (B, D1) to +5V through 450-680Ω"),
      (r"- Pull-down resistor: Connect B line to GND through 560-680Ω", "- Pull-down resistor: connect the inverting line (A, D0) to GND through 450-680Ω")],
 25: [(r"Consider implementations that support Modbus Security \(RFC in development\) or proprietary secured variants\.", "Consider Modbus/TCP Security (a published Modbus Organization specification using TLS on port 802) or proprietary secured variants.")],
 29: [(r"However, within a 16-bit register, the byte order follows[^\n]*", "Each 16-bit register is sent high byte first, always. Only the order of registers inside 32-bit and larger values is left to the device.")],
 30: [(r"Least significant word first, bytes swapped within each word", "Least significant word first, bytes inside each word unchanged (a pure word swap)")],
 31: [(r"   - Mid-big-endian \(BADC\)", "   - Bytes swapped within words (BADC)"), (r"   - Mid-little-endian \(CDAB\)", "   - Words swapped (CDAB)"),
      (r"// Mid-big-endian", "// bytes swapped within words"), (r"// Mid-little-endian", "// fully reversed"),
      (r"- \*\*Modicon convention\*\* \(original\): ABCD \(big-endian\)", "- **Common default**: ABCD (high word first); many devices use CDAB"),
      (r"Ensure floats start at even register addresses", "Some devices require floats to start at even register addresses (a device rule, not a Modbus rule)")],
 37: [(r"The traditional notation adds offsets \(10000, 30000, 40000\)[^\n]*", "The traditional notation adds a table prefix (the first digit 0, 1, 3 or 4) and is one-based: reference 40001 is protocol address 0. The protocol messages themselves use zero-based addresses within each space.")],
 53: [(r"The event counter increments each time the device successfully processes \*\*any\*\* Modbus message addressed to it, regardless of[^\n]*", "The event counter increments each time the device successfully completes a Modbus message addressed to it. Exception responses and the poll commands that read the counter are not counted."),
      (r"\*\*The Status Word\*\* contains two key pieces of information:", "**The Status Word** is one of two values:"),
      (r"- \*\*Bit 15 \(0x8000\)\*\*: Busy flag[^\n]*", "- **0xFFFF**: busy, a previous program command is still being processed"),
      (r"- \*\*Bits 0-14\*\*: Reserved[^\n]*", "- **0x0000**: not busy"),
      (r"- Does NOT increment for broadcast messages", "- Does not count exception responses or its own poll commands")],
 54: [(r"   - \*\*Bit 15 \(0x8000\)\*\*: Busy flag\n   - \*\*Bit 14 \(0x4000\)\*\*: Event log full\n   - \*\*Bits 8-13\*\*: Reserved\n   - \*\*Bits 0-7\*\*: Event log byte count", "   - **0xFFFF**: a program command is still being processed; **0x0000**: not busy"),
      (r"- \*\*Bit 7\*\*: 0 = Modbus event, 1 = Communication event\n- \*\*Bits 0-6\*\*: Event code specific to the event type", "- **Receive event**: bit 7 = 1, remaining bits are flags (communication error, broadcast received, listen-only mode)\n- **Send event**: bit 7 = 0 and bit 6 = 1, remaining bits are flags (exception sent, listen-only mode)\n- **0x04**: entered listen-only mode; **0x00**: communication restart"),
      (r"- \*\*High Byte \(bits 8-15\)\*\*: System status flags\n- \*\*Low Byte \(bits 0-7\)\*\*: Number of bytes in event log", "- **0xFFFF**: a program command is still being processed\n- **0x0000**: not busy"),
      (r"7\. \*\*Events\*\* \(variable\):", "7. **Events** (0 to 64 bytes):")],
 56: [(r"Maximum of 247 bytes in the request/response data field", "Request data length may be up to 251 bytes")],
 59: [(r"- \*\*0x0D-0x0F\*\*: Reserved for other encapsulated interfaces", "- **0x0F to 0xFF**: reserved")],
 96: [(r"\*\*1996 - Modbus Plus\*\*", "**Early 1980s - Modbus Plus**"), (r"\*\*2012 - Modbus Security\*\*", "**2018 - Modbus/TCP Security**"),
      (r"- Current: 100\+ defined codes", "- Current: public codes 1-64, 73-99 and 111-127, plus user-defined 65-72 and 100-110"),
      (r"13 standardized exception codes", "10 standardized exception codes (01-08, 0A, 0B)")],
 97: [(r"Modbus TCP/IP is classified as \*\*Type 18\*\* in the IEC 61158 standard family\.[^\n]*", "Modbus is referenced in international standards through IEC PAS 62030 and IEC 61784 profiles. It is **not** IEC 61158 Type 18 (Type 18 is CC-Link). This chapter therefore treats compliance as conformance to the Modbus Organization's specifications."),
      (r"For a Modbus implementation to be IEC 61158 Type 18 compliant, it must adhere to:", "For a typical Modbus TCP conformance profile, an implementation adheres to:"),
      (r"[^\n]*establishes Modbus TCP as a recognized industrial fieldbus protocol \(Type 18\)[^\n]*", "**IEC context**: Modbus is referenced in IEC standards (IEC PAS 62030 and IEC 61784 profiles) but is not IEC 61158 Type 18. Practical compliance means following the Modbus Organization specifications and conformance classes."),
      (r"- \*\*Standardization\*\*: Modbus TCP is officially recognized as IEC 61158 Type 18", "- **Standardization**: referenced in IEC PAS 62030; not Type 18"),
      (r"IEC 61158 Type 18 \(Modbus TCP\) compliant implementation", "Modbus TCP conformance-profile implementation"),
      (r"Connected to IEC 61158 Type 18 compliant Modbus server", "Connected to Modbus TCP server"),
      (r"Connect to Modbus TCP server \(IEC 61158 Type 18\)", "Connect to Modbus TCP server"),
      (r"IEC 61158 Type 18 \(Modbus TCP\) Client", "Modbus TCP Client")],
}
CODEFIX = {
 5: [("static constexpr auto CRC_TABLE = generateCRCTable();", "static inline const auto CRC_TABLE = generateCRCTable();")],
 24: [("    std::mutex mutex_;", "    mutable std::mutex mutex_;")],
 42: [("#include <stdint.h>\n", "#include <stdint.h>\n#include <fcntl.h>\n")],
 51: [("    uint8_t slave_address_;\n    \n    static uint16_t calculate_crc", "    uint8_t slave_address_;\npublic:\n    static uint16_t calculate_crc")],
 65: [("#include <iostream>\n", "#include <iostream>\n#include <fcntl.h>\n#include <unistd.h>\n")],
}
RENAME_ENUM = {29, 31, 33}

def _crc_table_text():
    tab=[]
    for i in range(256):
        c=i
        for _ in range(8): c=(c>>1)^0xA001 if c&1 else c>>1
        tab.append(c)
    rows=["    "+", ".join(f"0x{v:04X}" for v in tab[k:k+6])+("," if k+6<256 else "") for k in range(0,256,6)]
    return "\n".join(rows)
TABLEFIX = {42: "static const uint16_t crc_table[256] = {", 45: "static const uint16_t crc16_table[256] = {"}


def link_chapters(text):
    out = []; in_code = False
    for l in text.split("\n"):
        if l.startswith("```"): in_code = not in_code
        if in_code or l.startswith("#") or l.startswith("!["): out.append(l); continue
        def rep(m):
            seq = re.sub(r"\b(\d{1,3})\b", lambda k: f"[{k.group(1)}](#ch{int(k.group(1)):03d})", m.group(2))
            return m.group(1) + " " + seq
        l = re.sub(r"\b([Cc]hapters?)\s+((?:\d{1,3})(?:\s*(?:,|and|to)\s*\d{1,3})*)", rep, l)
        out.append(l)
    return "\n".join(out)

def box(n):
    t, one, ana, _ = C[n]
    s = "\n::: keybox\n**In one sentence.** " + one + "\n:::\n\n::: analogy\n**Analogy.** " + ana + "\n:::\n\n"
    if n in NOTES: s += "::: warning\n**Editor's note.** " + NOTES[n] + "\n:::\n\n"
    if EXTRA.get(n):
        name, cap, w = EXTRA[n]; s += f"![{cap}](img/{name}.png){{width={w}%}}\n\n"
    return s

def inline_src(n, t):
    if n != 57: return t
    for ext, lang in (("cpp", "cpp"), ("rs", "rust")):
        link = re.search(r"\[MQTT_SN_Gateway_Implementation\." + ext + r"\]\([^)]*\)<br>\n?", t)
        code = open(f"{SRCCODE}/57/MQTT_SN_Gateway_Implementation.{ext}").read()
        if link: t = t.replace(link.group(0), f"```{lang}\n{code}\n```\n")
    return t

def prep(n, path):
    t = open(path, encoding="utf-8").read()
    for pat, rep in TEXTFIX.get(n, []):
        t2 = re.sub(pat, rep, t, flags=re.S)
        if t2 == t: print("WARN textfix not applied", n, pat[:50])
        t = t2
    for old, new in CODEFIX.get(n, []):
        if old not in t: print("WARN codefix not applied", n, old[:40])
        t = t.replace(old, new, 1) if n in (42,) else t.replace(old, new)
    if n in TABLEFIX:
        mk = TABLEFIX[n]
        a = t.index(mk); b = t.index("};", a)
        t = t[:a] + mk + "\n" + _crc_table_text() + "\n" + t[b:]
        t = t.replace("    // ... (full table would contain all 256 entries)\n","").replace("    // ... (full table omitted for brevity)\n","")
    if n in RENAME_ENUM:
        t = re.sub(r"\bBIG_ENDIAN\b", "ORDER_BIG_ENDIAN", t); t = re.sub(r"\bLITTLE_ENDIAN\b", "ORDER_LITTLE_ENDIAN", t)
    t = blib.clean_text(t)
    lines = t.split("\n"); out = []; in_code = False; first = True
    for l in lines:
        if l.startswith("```"): in_code = not in_code
        if not in_code and re.match(r"^# ", l):
            if first: first = False; continue
            l = "#" + l            # demote stray h1
        out.append(l)
    t = "\n".join(out)
    t = re.sub(r"^\*\*QoS [012] Flow:\*\*\s*$", "", t, flags=re.M) if n == 2 else t
    t = blib.process_code_blocks(t, n)
    t = blib.convert_tables(t)
    t = re.sub(r"^---\s*$", "", t, flags=re.M)
    t = re.sub(r"^## (Summary)\s*$", "## Summary", t, flags=re.M)
    title, one, ana, bl = C[n]
    t = f"# {n:02d}. {title} {{#ch{n:03d}}}\n" + box(n) + t.lstrip("\n")
    t = t.rstrip() + "\n\n## Things to Remember\n\n" + "\n".join("- " + b for b in bl) + "\n"
    return link_chapters(t)

def main():
    files = {int(os.path.basename(f)[:2] if os.path.basename(f)[:3] != "100" else 100): f for f in glob.glob(SRC + "/[0-9][0-9]*_*.md")}
    files = {}
    for f in glob.glob(SRC + "/*_*.md"):
        b = os.path.basename(f); num = int(b.split("_")[0])
        if num >= 1: files[num] = f
    assert sorted(files) == list(range(1, 101)), sorted(files)[:5]
    chap = {n: prep(n, files[n]) for n in files}
    parts = [("000_preface", open(NEW + "/00_preface.md").read()), ("001_story", open(NEW + "/00b_story.md").read())]
    idx = 2
    for pi, (name, rng, blurb, intro) in enumerate(PARTS, 1):
        parts.append((f"{idx:03d}_part{pi}", f"# Part {pi}: {name} {{#part{pi} .unnumbered .part}}\n\n*{blurb}*\n\n{intro}\n")); idx += 1
        for n in rng:
            parts.append((f"{idx:03d}_ch{n:03d}", chap[n])); idx += 1
    ra = ["# Appendix A: The Refresher {#appA}\n", "Every chapter's *Things to Remember*, in order. Tap a chapter title to jump to the full explanation.\n"]
    for pi, (name, rng, _, _) in enumerate(PARTS, 1):
        ra.append(f"\n## Part {pi}: {name}\n")
        for n in rng:
            ra.append(f"\n**[{n:02d}. {C[n][0]}](#ch{n:03d})**\n")
            ra.append("\n".join("- " + b for b in C[n][3]) + "\n")
    parts.append((f"{idx:03d}_appA", "\n".join(ra))); idx += 1
    for nm in ["B_cheat", "C_trouble", "D_glossary", "E_further", "F_corrections"]:
        t = blib.process_code_blocks(blib.clean_text(open(f"{NEW}/{nm}.md").read()), 0)
        t = blib.convert_tables(t)
        if nm == "D_glossary":
            t = re.sub(r"\[(\d{1,3}(?:,\s*\d{1,3})*)\]\s*$", lambda m: "[" + ", ".join(f"[{x}](#ch{int(x):03d})" for x in re.split(r",\s*", m.group(1))) + "]", t, flags=re.M)
        t = link_chapters(t)
        parts.append((f"{idx:03d}_{nm}", t)); idx += 1
    for name, text in parts:
        open(f"{OUT}/{name}.md", "w").write(text.rstrip() + "\n\n")
    print("files", len(parts))
main()
