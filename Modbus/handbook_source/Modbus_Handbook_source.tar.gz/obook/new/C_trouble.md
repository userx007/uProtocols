# Appendix C: Troubleshooting Quick Path {#appC}

Start at the top and stop at the first thing that is wrong.

## No Response at All (Timeout)

**Serial (RTU/ASCII)**

1. **Serial settings.** Baud rate, parity, data bits and stop bits must match on every device. A parity mismatch looks like constant CRC errors.
2. **Address.** Is the slave address correct and unique on the bus? Broadcast (0) never gets a reply.
3. **Wiring.** A and B swapped is the classic fault (labels differ between vendors). Check termination, bias and common reference.
4. **Direction control.** The RS-485 driver must switch to receive right after the last stop bit.
5. **Timing.** USB adapters and operating systems may break the 3.5-character gap.

**TCP**

1. **Reachability.** Can you reach the IP and port 502? Firewalls often block it.
2. **Unit ID.** Direct devices may ignore it or want 0xFF; gateways need the serial address.
3. **Connection limits.** Many small devices accept only a few simultaneous clients.

## Exception Replies

| Exception | First thing to check |
|---|---|
| 01 | Function code not supported by this device |
| 02 | Address off by one, or outside the device's map |
| 03 | Quantity or value out of range |
| 04 | Device fault; check the device itself |
| 06 | Device busy; retry with delay |
| 0A or 0B | Gateway path or target device problem |

## Wrong Values

- **Off-by-one address.** Manuals that list 40001 mean protocol address 0.
- **Word order.** A float that looks absurd is usually the wrong word order (ABCD vs CDAB).
- **Scaling and signedness.** Tenths of a degree, two's complement values.
- **Wrong table.** Holding vs input registers.

## Intermittent CRC Errors

Noise, missing termination, ground loops, long stubs, wrong parity, or two devices talking at once (two masters or a duplicate address).

## Tools

Wireshark filter `mbtcp` for TCP, an RS-485 listener for serial, and the diagnostic counters of FC 08 (chapters 48, 49 and 52).
