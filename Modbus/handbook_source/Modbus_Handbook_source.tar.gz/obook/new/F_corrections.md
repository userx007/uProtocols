# Appendix F: Corrections Log {#appF}

This edition was checked against the Modbus specifications and by recomputing examples. The following issues were found in the source text and fixed.

## Wrong examples and values

| Chapter | Original | Correction |
|---|---|---|
| 3 | ASCII example frame `:1103E8000275` | The frame was missing a byte and the LRC was wrong. Correct frame: `:110303E80002FF` (LRC = FF). |

## Wrong or misleading statements

| Chapter | Original claim | Correction |
|---|---|---|
| 1 | Protocol created by Dick Morley and the Modicon team | Modbus was created at Modicon. The attribution to one person was removed. |
| 17 | Pull line A high and B low when idle | Idle polarity: the non-inverting line (B, D1) must be above the inverting line (A, D0). Labels differ between vendors. Termination in the Modbus serial spec is about 150 ohm; 120 ohm is common. |
| 18 | RTU is normally 8N1 | The specification default is 8E1 (11-bit characters); 8N2 is the allowed no-parity form. 8N1 is common in practice but non-conforming. |
| 25 | Modbus Security is an "RFC in development" | Modbus/TCP Security is a published Modbus Organization specification using TLS on port 802. |
| 29 | Byte order inside a register "follows the specification" | Each register is sent high byte first, always. |
| 30 | CDAB means bytes swapped within each word | CDAB swaps only the words; bytes stay in order. |
| 31 | "Mid-big" and "mid-little" labels for BADC and CDAB; floats must start at even addresses; Modicon convention ABCD | Naming varies between sources, so the labels were removed. Even alignment is a device rule, not a Modbus rule. Word order is device-specific. |
| 37 | Traditional notation only adds offsets 10000, 30000, 40000 | The reference number is also one-based (40001 is address 0). |
| 53 | Counter increments for failed messages too; status word is a bit 15 flag | It counts successful messages only. Status is 0xFFFF when busy and 0x0000 otherwise. |
| 54 | Status bit flags; event byte bit 7 distinguishes event types | Status is 0xFFFF or 0x0000. Receive events have bit 7 set; send events have bit 7 clear and bit 6 set. At most 64 event bytes. |
| 56 | Maximum 247 bytes of request data | Request data length may be up to 251 bytes. |
| 59 | MEI types 0x0D to 0x0F are reserved | 0x0D is CANopen General Reference, 0x0E is Read Device Identification. |
| 71 | Port 502 (implied) | Secured Modbus/TCP uses port 802. |
| 72 | Modbus UDP presented as a transport | Not part of the Modbus specification; some products implement it. |
| 96 | Modbus Plus in 1996; security in 2012; 100+ function codes; 13 exception codes | Modbus Plus dates from the 1980s; Modbus/TCP Security from 2018; user-defined codes are 65 to 72 and 100 to 110; there are 10 defined exception codes. |
| 97 | Modbus TCP is IEC 61158 Type 18 | Type 18 is not Modbus. Modbus is covered by IEC PAS 62030 and related profiles. |

## Code fixes

| Chapter | Problem | Fix |
|---|---|---|
| 5 | constexpr table called before the class is complete | Table is now a static inline const |
| 42, 45 | CRC lookup tables were truncated ("full table omitted"), so the C code gave wrong CRCs | Replaced with the complete 256-entry table, verified with `01 03 00 00 00 0A` giving `C5 CD` |
| 24 | Locking a mutex in a const method | Mutex is now `mutable` |
| 29, 31, 33 | Enum names `BIG_ENDIAN` and `LITTLE_ENDIAN` collide with system macros | Renamed with an `ORDER_` prefix |
| 42, 65 | Missing `#include <fcntl.h>` | Added |
| 51 | Private helper used from outside the class | Made public |

## Not changed, but flagged

- Code in the application chapters (81 to 90) uses example register maps. They are not real device maps.
- Several C listings are fragments that rely on headers or types defined elsewhere in the same chapter.
