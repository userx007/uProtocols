# About This Book {#preface .unnumbered}

This handbook has two jobs.

**First, it teaches.** Every chapter opens with a one-sentence summary and a plain-language analogy, then explains the idea properly, with working C/C++ and Rust code.

**Second, it is a reference for quick refreshers.** Every chapter ends with a *Things to Remember* list. Appendix A collects all of them. The other appendices hold the facts you look up most often: function codes, exception codes, limits, frame layouts, address notation, 32-bit word orders, timing and RS-485 basics.

## This edition was fact-checked

The source material was reviewed before it was turned into this book. Worked examples were recomputed (CRC and LRC values), all 24 C/C++ CRC functions and all 4 LRC functions were run against test vectors, every C and C++ listing was compile-checked, and the prose was compared with the Modbus specifications. Errors that were found are corrected in the text, and places where the original claim was wrong or misleading are marked with an **Editor's note**. Appendix F lists every correction.

## How each chapter is built

::: keybox
**In one sentence.** The whole chapter, compressed to a line you can reread in five seconds.
:::

::: analogy
**Analogy.** A familiar picture that carries the idea. Analogies are teaching aids; where they stop being accurate, the main text takes over.
:::

Then come the detailed sections with code, a **Summary**, and **Things to Remember**.

## Three ways to read it

**Learning from scratch.** Read Parts 1 to 3 in order (chapters 1 to 22), then Part 5 (data processing) and the TCP part if you use Ethernet.

**Fast refresh.** Read the *In one sentence* and *Analogy* boxes, then Appendix A and B.

**Debugging right now.** Go to Appendix C, then chapters 16, 21 and 48.

## Conventions

- References such as *chapter 29* are links. Tap them to jump.
- Long code lines are wrapped; a wrapped line is still one statement.
- Code is illustrative. Check library versions and hardware details before shipping.
- Register maps in the application chapters (81 to 90) are examples. **Your device's manual always wins.**
- Hex values are written `0x1F`; bytes in frames are shown as `1F`.

## Terminology

*Master/slave* and *client/server* mean the same thing here. Serial documents say master and slave; Modbus TCP documents say client and server.
