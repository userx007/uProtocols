# Appendix D: Glossary {#appD}

**ADU**
: Application Data Unit: the PDU plus the transport wrapper (address and CRC for RTU, MBAP for TCP). [1, 4]

**Broadcast**
: Address 0 on serial lines; all slaves act, none reply. [22]

**CRC-16**
: 16-bit checksum of RTU frames. [5]

**Coil**
: Read/write single-bit object. [7, 37]

**Discrete input**
: Read-only single-bit object. [8, 37]

**Exception response**
: Reply with function code + 0x80 and an exception code. [16]

**Function code**
: One byte that says what operation is requested. [7 to 15]

**Gateway**
: Device that converts between Modbus TCP and serial Modbus. [61, 62]

**Holding register**
: Read/write 16-bit object. [9, 37]

**Input register**
: Read-only 16-bit object. [10, 37]

**LRC**
: 8-bit checksum of ASCII frames. [6]

**MBAP**
: Modbus Application Protocol header of Modbus TCP, 7 bytes. [4]

**Master / client**
: The device that sends requests. [36]

**PDU**
: Protocol Data Unit: function code plus data. [1]

**RTU**
: Binary serial framing with CRC-16. [2]

**Slave / server**
: The device that answers requests. [35]

**t3.5**
: Silent interval of 3.5 character times that separates RTU frames. [19, 21]

**Transaction ID**
: Number that lets a TCP client match responses to requests. [26]

**Unit ID**
: Last MBAP byte, selects a slave behind a gateway. [4, 61]

**Word order**
: Order of registers inside a multi-register value. [29, 30]
