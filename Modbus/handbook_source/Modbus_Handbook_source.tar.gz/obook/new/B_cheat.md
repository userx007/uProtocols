# Appendix B: Cheat Sheets {#appB}

## B.1 Public Function Codes

| Code | Name | Notes |
|---|---|---|
| 0x01 | Read Coils | up to 2000 |
| 0x02 | Read Discrete Inputs | up to 2000 |
| 0x03 | Read Holding Registers | up to 125 |
| 0x04 | Read Input Registers | up to 125 |
| 0x05 | Write Single Coil | 0xFF00 on, 0x0000 off |
| 0x06 | Write Single Register | |
| 0x07 | Read Exception Status | serial line only |
| 0x08 | Diagnostics | serial line only |
| 0x0B | Get Comm Event Counter | serial line only |
| 0x0C | Get Comm Event Log | serial line only |
| 0x0F | Write Multiple Coils | up to 1968 |
| 0x10 | Write Multiple Registers | up to 123 |
| 0x11 | Report Server ID | serial line only |
| 0x14 | Read File Record | |
| 0x15 | Write File Record | |
| 0x16 | Mask Write Register | |
| 0x17 | Read/Write Multiple Registers | read up to 125, write up to 121 |
| 0x18 | Read FIFO Queue | up to 31 registers |
| 0x2B | Encapsulated Interface Transport | MEI 0x0E reads device identification |

User-defined function codes: 65 to 72 (0x41 to 0x48) and 100 to 110 (0x64 to 0x6E).

## B.2 Exception Codes

| Code | Name | Meaning |
|---|---|---|
| 0x01 | Illegal Function | Function not supported |
| 0x02 | Illegal Data Address | Address not allowed |
| 0x03 | Illegal Data Value | Value or quantity not allowed |
| 0x04 | Server Device Failure | Unrecoverable error while executing |
| 0x05 | Acknowledge | Accepted, long operation in progress |
| 0x06 | Server Device Busy | Try again later |
| 0x07 | Negative Acknowledge | Cannot perform the program function |
| 0x08 | Memory Parity Error | Extended memory parity error |
| 0x0A | Gateway Path Unavailable | Gateway misconfigured or overloaded |
| 0x0B | Gateway Target Failed to Respond | No answer from the target device |

## B.3 Frame Sizes and Limits

| Item | Value |
|---|---|
| RTU frame | address 1 + PDU up to 253 + CRC 2 = 256 bytes |
| ASCII frame | colon + hex pairs + LRC pair + CR LF |
| TCP frame | MBAP 7 + PDU up to 253 = 260 bytes |
| Slave addresses | 1 to 247; 0 broadcast; 248 to 255 reserved |
| RS-485 devices per segment | 32 unit loads |

## B.4 Verified Example Frames (RTU)

Every CRC below was recomputed. Frames are shown as bytes with the two CRC bytes (low byte first) at the end.

| Meaning | Frame |
|---|---|
| Read 10 holding registers from address 100 (device 1) | `01 03 00 64 00 0A 84 12` |
| Read 3 holding registers from address 107 (device 17) | `11 03 00 6B 00 03 76 87` |
| Write single coil 172 ON (device 1) | `01 05 00 AC FF 00 4C 1B` |
| Write single register 1 = 3 (device 1) | `01 06 00 01 00 03 98 0B` |
| Write 2 registers from address 1 = 000A, 0102 (device 1) | `01 10 00 01 00 02 04 00 0A 01 02 92 30` |
| Exception reply: illegal data address to an FC 03 | `01 83 02 C0 F1` |

## B.5 Verified Example Frame (ASCII)

Read 2 holding registers from address 1000 (0x03E8) in device 17:

`:110303E80002FF` followed by CR LF

## B.6 Address Notation

| Table | Traditional range | Protocol address |
|---|---|---|
| Coils | 00001 to 09999 | reference minus 1 |
| Discrete inputs | 10001 to 19999 | reference minus 10001 |
| Input registers | 30001 to 39999 | reference minus 30001 |
| Holding registers | 40001 to 49999 | reference minus 40001 |

Six-digit notation (for example 400001) covers all 65,536 addresses. **Holding register 40001 is protocol address 0.** Always check whether a device manual counts from 0 or from 1.

## B.7 32-bit Value Orders

Value 0x12345678, bytes A=12 B=34 C=56 D=78, shown as the two registers in the order they are read:

| Name | Register 1 | Register 2 | Meaning |
|---|---|---|---|
| ABCD | 0x1234 | 0x5678 | High word first |
| CDAB | 0x5678 | 0x1234 | Low word first (word swap) |
| BADC | 0x3412 | 0x7856 | High word first, bytes swapped in each word |
| DCBA | 0x7856 | 0x3412 | Fully reversed |

## B.8 Serial Timing

| Baud rate | Character (11 bits) | t1.5 | t3.5 |
|---|---|---|---|
| 9600 | 1.146 ms | 1.72 ms | 4.01 ms |
| 19200 | 0.573 ms | 0.86 ms | 2.00 ms |
| above 19200 | | 750 µs fixed | 1.75 ms fixed |

## B.9 RS-485 Quick Facts

- Daisy-chain topology, termination at both ends (the Modbus serial specification calls for about 150 ohm; 120 ohm is common).
- Bias so that the non-inverting line (B, D1) is above the inverting line (A, D0) when idle. Labels A and B differ between vendors.
- 32 unit loads per segment; up to 1200 m at low speed.
- Default serial format in the specification: 8 data bits, even parity, 1 stop bit; 8N2 is the no-parity option.

## B.10 Checksums

- **CRC-16**: init 0xFFFF, polynomial 0xA001 (reflected), no final XOR, low byte first. `01 03 00 00 00 0A` gives `C5 CD`.
- **LRC**: two's complement of the 8-bit sum of the decoded bytes. `11 03 03 E8 00 02` gives `FF`.
