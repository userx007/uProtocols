# The Big Picture in One Page {#bigpicture .unnumbered}

## The classroom story

A teacher stands in front of a class where every pupil has a **number** (1 to 247). Each pupil has **four cabinets**:

- **Coils**: switches the teacher may read and flip.
- **Discrete inputs**: indicator lamps the teacher may only look at.
- **Holding registers**: numbered cards the teacher may read and rewrite.
- **Input registers**: gauges the teacher may only read.

The teacher asks: *"Pupil 7, read me 10 cards starting at card 100."* That is a **request** with a **function code** (03). Pupil 7 answers with the cards, or says *"cannot do that, reason 02"* (an **exception**). **Nobody else speaks**, and pupils never talk among themselves.

On a **serial line** the teacher shouts across the room and the end of a sentence is marked by silence (RTU) or by punctuation (ASCII). On **Ethernet** (Modbus TCP) the question goes through an intercom in an envelope with a ticket number.

## The picture

![The same PDU in three wrappers](img/frames.png){width=80%}

## Fact table

| Item | Value |
|---|---|
| Valid slave addresses | 1 to 247 (0 = broadcast) |
| Read coils or discrete inputs | up to 2000 per request |
| Read registers | up to 125 per request |
| Write coils | up to 1968 per request |
| Write registers | up to 123 per request |
| Maximum RTU frame | 256 bytes |
| Maximum TCP frame | 260 bytes |
| TCP port | 502 (802 for TLS) |
| CRC | CRC-16, init 0xFFFF, polynomial 0xA001, low byte first |
| Exception reply | function code + 0x80, then one code byte |

## Five sentences to remember

1. **The master asks, the slave answers**, one transaction at a time on a serial bus.
2. **The PDU (function code plus data) is the same** in RTU, ASCII and TCP.
3. **Registers are 16 bits and travel high byte first**; the order of registers in 32-bit values is up to the device.
4. **Addresses in the protocol start at 0**; manuals often start at 1 (40001 means address 0).
5. **Modbus has no security of its own**; protect it with the network around it.
