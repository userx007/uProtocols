C = {}
C[1] = ("Modbus Protocol Overview",
 "Modbus is a simple request-response protocol in which one master (client) asks addressed slaves (servers) to read or write bits and 16-bit registers, over serial lines or TCP.",
 "Picture a **teacher in a classroom** with a roll call. The teacher (master) asks one pupil at a time by number: *\"Pupil 7, what is the value in your box number 100?\"* Only the pupil addressed answers; the others stay silent. Pupils never talk to each other. The same questions work whether the teacher shouts across the room (serial line) or sends a note through the school intercom (TCP).",
 ["**Created by Modicon in 1979**; openly published, now maintained by the Modbus Organization.","**Master/client asks, slave/server answers.** Only the master starts a transaction.","**Three common framings**: RTU (binary serial), ASCII (text serial), TCP (Ethernet, port 502).","**Same PDU everywhere**: function code plus data; only the wrapper changes.","**Four data tables**: coils, discrete inputs, holding registers, input registers."])
C[2] = ("Modbus RTU Frame Structure",
 "An RTU frame is address, function code, data and a CRC-16, delimited by silence of at least 3.5 character times.",
 "An RTU frame is a **telegram with no punctuation**: the receiver knows it has ended only because the line goes quiet for a moment, like the pause after a spoken sentence. The CRC is the **check-sum sticker** at the end that proves nothing was garbled.",
 ["**Frame**: address (1) + function (1) + data (n) + CRC (2).","**Addresses**: 1 to 247 for devices, 0 for broadcast, 248 to 255 reserved.","**CRC is sent low byte first.**","**Maximum RTU frame is 256 bytes** (so PDU data is at most 253 bytes).","**Silence of 3.5 characters** separates frames; at 9600 baud with 11-bit characters that is about 4 ms."])
C[3] = ("Modbus ASCII Frame Structure",
 "An ASCII frame starts with a colon, carries every byte as two hex characters, ends with an LRC and CR LF.",
 "ASCII mode is **writing the telegram out in readable letters**: twice as long, but a human with a terminal can read it, and the colon and line-end mark exactly where it starts and stops.",
 ["**Frame**: `:` + address + function + data + LRC + CR LF, all as hex text.","**Each byte becomes two ASCII characters**, so frames are about twice as long as RTU.","**LRC** is the two's complement of the 8-bit sum of the bytes.","**Example**: `:110303E80002FF` followed by CR LF reads 2 registers at 1000 from device 17.","**Timing is relaxed**: delimiters mark frame boundaries, the gap between characters can be up to one second."])
C[4] = ("Modbus TCP/IP Frame Structure",
 "Modbus TCP puts the PDU behind a 7-byte MBAP header and drops the CRC because TCP already checks integrity.",
 "TCP framing is **the same question in an addressed, numbered envelope**: the envelope carries a ticket number (transaction ID) so answers can be matched to questions, and a length so the receiver knows where this letter ends and the next begins.",
 ["**MBAP**: transaction ID (2), protocol ID (2, always 0), length (2), unit ID (1).","**Length** counts unit ID + function code + data.","**No CRC** in Modbus TCP.","**Maximum ADU is 260 bytes** (7 + 253).","**Unit ID** selects a slave behind a gateway; direct devices usually ignore it (0xFF is common)."])
C[5] = ("CRC-16 Calculation Algorithm",
 "Modbus CRC-16 starts at 0xFFFF, processes bytes with the reflected polynomial 0xA001 and is appended low byte first.",
 "A CRC is a **fingerprint of the message**: change one bit anywhere and the fingerprint changes. The receiver recomputes it and compares.",
 ["**Init 0xFFFF, polynomial 0xA001 (reflected 0x8005), no final XOR.**","**Per byte**: XOR into the low byte, then 8 shift-right steps with conditional XOR.","**Check vector**: bytes `01 03 00 00 00 0A` give CRC bytes `C5 CD`.","**Sent low byte first.**","**Receiver check**: CRC over the whole frame including CRC bytes is 0."])
C[6] = ("LRC Calculation Algorithm",
 "LRC is the two's complement of the 8-bit sum of the message bytes, used only in ASCII mode.",
 "A **running total with a sign flip**: add everything up, throw away the overflow, and negate so that message plus LRC adds to zero.",
 ["**LRC = (0x100 - (sum & 0xFF)) & 0xFF**.","**Computed over the decoded binary bytes**, not the ASCII characters.","**Excludes** the colon, the LRC itself and CR LF.","**Check vector**: bytes `11 03 03 E8 00 02` give LRC `FF`.","**Weaker than CRC-16**; fine for ASCII's use cases."])
C[7] = ("Function Code 0x01: Read Coils",
 "FC 01 reads 1 to 2000 coils and returns them packed 8 per byte, first coil in the least significant bit.",
 "A **row of light switches**: you ask *\"which of switches 20 to 39 are on?\"* and get a strip of ones and zeros back, eight to a byte.",
 ["**Request**: start address (2) + quantity (2).","**Quantity 1 to 2000.**","**Response**: byte count + packed bits, first coil in bit 0 of the first byte.","**Unused high bits** of the last byte are zero.","**Coils are read/write**; typically relay outputs."])
C[8] = ("Function Code 0x02: Read Discrete Inputs",
 "FC 02 reads 1 to 2000 read-only single-bit inputs, packed like coils.",
 "The **indicator lamps** on the panel: you can look but not touch.",
 ["**Same format as FC 01.**","**Quantity 1 to 2000.**","**Read-only** inputs such as limit switches.","**Separate address space** from coils.","**Bit packing** is LSB first."])
C[9] = ("Function Code 0x03: Read Holding Registers",
 "FC 03 reads 1 to 125 consecutive 16-bit read/write registers.",
 "A **notebook with numbered lines**, each holding one number you may read and edit: setpoints, configuration, and often measurements too.",
 ["**Quantity 1 to 125.**","**Response**: byte count (2 x quantity) + data, each register high byte first.","**The most used function code.**","**Addresses are zero-based in the PDU** (register 40001 is address 0).","**Multi-register values** (32-bit, float) need agreed word order."])
C[10] = ("Function Code 0x04: Read Input Registers",
 "FC 04 reads 1 to 125 read-only 16-bit registers, typically analog measurements.",
 "The **gauges on the dashboard**: read-only numbers fed by sensors.",
 ["**Same format as FC 03.**","**Quantity 1 to 125.**","**Read-only**; writes are rejected.","**Many devices mirror data** in both holding and input registers.","**Check the vendor's map** for scaling and units."])
C[11] = ("Function Code 0x05: Write Single Coil",
 "FC 05 sets one coil: 0xFF00 means ON, 0x0000 means OFF; the response echoes the request.",
 "**Flipping one switch**, and the slave repeats back what you asked as confirmation.",
 ["**ON = 0xFF00, OFF = 0x0000**; any other value is illegal.","**Response echoes the request.**","**Broadcast address 0** writes to all slaves without replies.","**Exception 03** for a bad value.","**Use FC 0F** for many coils."])
C[12] = ("Function Code 0x06: Write Single Register",
 "FC 06 writes one 16-bit holding register; the response echoes the request.",
 "**Changing one number in the notebook.**",
 ["**Request**: address (2) + value (2).","**Response echoes** address and value.","**One register only**; use FC 10 for more.","**Broadcast possible** (address 0, no reply).","**Writes may be range-checked**; expect exception 03."])
C[13] = ("Function Code 0x0F: Write Multiple Coils",
 "FC 0F writes 1 to 1968 coils packed 8 per byte.",
 "**Setting a whole row of switches in one go** from a strip of bits.",
 ["**Quantity 1 to 1968.**","**Request**: start (2), quantity (2), byte count (1), packed bits.","**Response** returns start address and quantity.","**Byte count = ceil(quantity / 8).**","**LSB first** packing."])
C[14] = ("Function Code 0x10: Write Multiple Registers",
 "FC 10 writes 1 to 123 consecutive holding registers.",
 "**Filling several lines of the notebook** in a single message.",
 ["**Quantity 1 to 123** (246 data bytes).","**Request**: start, quantity, byte count, data.","**Response**: start address and quantity.","**Writes are not guaranteed atomic** across vendors.","**Write related values together**, e.g. both halves of a 32-bit number."])
C[15] = ("Function Code 0x17: Read/Write Multiple Registers",
 "FC 17 performs a write and then a read in one transaction: read up to 125, write up to 121 registers.",
 "**Handing in your answer sheet and receiving the next one in the same breath.**",
 ["**Read quantity 1 to 125, write quantity 1 to 121.**","**The write is performed before the read.**","**Saves one round trip** on slow links.","**Not supported by every device.**","**Response contains only the read data.**"])
C[16] = ("Exception Response Handling",
 "A slave that cannot execute a request replies with the function code plus 0x80 and a one-byte exception code.",
 "The pupil says *\"I can't answer that, and here is why\"* instead of staying silent: **wrong question (01), no such box (02), bad value (03), I broke (04)**.",
 ["**Exception function = request function + 0x80.**","**01** illegal function, **02** illegal data address, **03** illegal data value, **04** device failure.","**05** acknowledge, **06** busy, **07** negative acknowledge, **08** memory parity error.","**0A** gateway path unavailable, **0B** gateway target failed to respond.","**No response at all** (timeout) is different from an exception."])
C[17] = ("RS-485 Hardware Configuration",
 "RS-485 uses a twisted pair with differential signalling; a daisy-chained bus with termination at both ends carries Modbus RTU.",
 "A **party line** on one shared cable, where everybody listens and only the addressed device talks. Terminators at the two ends **absorb the echoes** like cushions at the end of a pool table.",
 ["**Daisy chain**, never a star; keep stubs very short.","**Terminate both ends**; the Modbus serial spec calls for about 150 ohm, 120 ohm is common.","**Bias resistors** hold the idle state; the non-inverting line (B, D1, labelled + on many devices) must be above the inverting line (A, D0, -) when idle. A/B labelling differs between vendors.","**32 unit loads per segment**, 1200 m at low speeds.","**Use shielded twisted pair**; ground the shield properly."])
C[18] = ("Serial Port Configuration",
 "Both ends must agree on baud rate, parity, data bits and stop bits.",
 "Two people on a radio must **agree on speed and accent** before the conversation can start.",
 ["**Match baud, parity, data bits, stop bits** on every device.","**The Modbus serial spec defaults to 8 data bits with even parity, 1 stop bit** (8E1); 8N2 is the allowed no-parity option; many devices also accept 8N1.","**ASCII mode uses 7 data bits**.","**Common baud rates**: 9600, 19200 (the two the spec requires), then higher.","**Wrong parity is the classic cause of CRC errors.**"])
C[19] = ("Serial Timeout Management",
 "RTU needs an inter-character timeout (1.5 characters) and an inter-frame gap (3.5 characters); above 19200 baud fixed values of 750 µs and 1750 µs are used.",
 "Two stopwatches: one says *\"a long pause inside a word means the sender stalled\"*, the other says *\"a longer pause means the sentence is finished\"*.",
 ["**t1.5 = 1.5 characters, t3.5 = 3.5 characters.**","**Above 19200 baud use fixed t1.5 = 750 µs and t3.5 = 1.75 ms.**","**A character is 11 bits** with parity, 10 without.","**Response timeout** is separate: typically 100 ms to 1 s.","**Turnaround delay** after broadcasts."])
C[20] = ("Serial Port Libraries",
 "Use platform serial APIs (termios, Win32, serialport crates) and configure raw mode carefully.",
 "The **plumbing** under the protocol: get it right once and then forget it.",
 ["**Linux**: `termios`, raw mode, no echo, no flow control.","**Set VMIN/VTIME** sensibly.","**RS-485 direction control** via the driver or a GPIO.","**Cross-platform**: serialport (Rust), libserialport.","**USB adapters add latency** that can break t3.5."])
C[21] = ("RTU 3.5 Character Gap Detection",
 "Frame end is detected by a timer restarted at every received byte; software timing is the weak point at high baud rates.",
 "A **kitchen timer reset by every word**: when it finally rings, the sentence is over.",
 ["**Restart a timer on each received byte.**","**Timer expiry = end of frame.**","**3.5 characters** at 9600 baud is about 4 ms; at 19200 about 2 ms.","**Above 19200 baud use 1.75 ms.**","**Operating systems may add jitter**; hardware or driver timers help."])
C[22] = ("Multi-Drop Network Configuration",
 "Up to 247 addressed slaves share one bus under a single master, each with a unique address.",
 "A **street of numbered houses** with one postman: only the house the postman calls answers the door.",
 ["**Addresses 1 to 247 must be unique.**","**Address 0 is broadcast**, with no responses.","**One master** initiates all traffic.","**Electrical limit** of 32 unit loads unless repeaters or low-load transceivers are used.","**Poll sequentially** and handle timeouts per slave."])
C[23] = ("TCP Socket Programming",
 "A Modbus TCP client opens a TCP connection to port 502, sends MBAP+PDU and reads exactly the length announced.",
 "Make a **phone call and keep the line open**: dial once, ask many questions, and listen for exactly as many words as the header promises.",
 ["**Connect to port 502.**","**Read the 7-byte MBAP, then `length - 1` more bytes.**","**TCP is a stream**: one read may return part of a frame or several frames.","**Set connect and read timeouts.**","**Disable Nagle (TCP_NODELAY)** for lower latency."])
C[24] = ("TCP Connection Management",
 "Keep connections open, detect dead ones and reconnect with backoff.",
 "**Keeping the phone line alive**, and calling back politely when it drops.",
 ["**Reuse one connection** for many requests.","**Detect dead peers** with timeouts and keep-alive.","**Reconnect with backoff.**","**Limit connections** on small devices.","**Close cleanly** to avoid exhausting server slots."])
C[25] = ("Modbus TCP Port 502",
 "Port 502 is the registered Modbus TCP port; Modbus carries no authentication or encryption of its own.",
 "Port 502 is the **front door with no lock**: anyone who can reach it can ask or command.",
 ["**TCP 502** is the standard server port.","**No built-in authentication or encryption.**","**Firewall it**: allow only known clients.","**Segment** control networks; never expose port 502 to the internet.","**Modbus/TCP Security** (TLS) uses port 802."])
