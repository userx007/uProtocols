import sys, subprocess
sys.path.insert(0, "/home/claude/book")
import dia
dia.OUT = "/home/claude/obook/img"
render = dia.render; OUT = dia.OUT
D = {}
D["frames"] = ("""
 rankdir=TB; node [shape=record, style=filled, fillcolor="#f2f2f2"];
 rtu [label="{Modbus RTU (serial, binary)}|{Address 1 B|<p>PDU: function code + data|CRC-16 2 B (low byte first)}"];
 asc [label="{Modbus ASCII (serial, text)}|{':' start|Address 2 chars|PDU as hex chars|LRC 2 chars|CR LF}"];
 tcp [label="{Modbus TCP (Ethernet)}|{MBAP header 7 B|PDU: function code + data}"];
 pdu [label="PDU = function code + data\\n(identical in all three, max 253 bytes)", shape=box, style="filled,rounded", fillcolor="#dddddd"];
 rtu -> pdu [style=dotted, arrowhead=none]; asc -> pdu [style=dotted, arrowhead=none]; tcp -> pdu [style=dotted, arrowhead=none];
""", 800)
D["mbap"] = ("""
 rankdir=TB; node [shape=record, style=filled, fillcolor="#f2f2f2"];
 m [label="{MBAP header (7 bytes)}|{Transaction ID\\n2 B|Protocol ID\\n2 B = 0000|Length\\n2 B|Unit ID\\n1 B}"];
 p [label="{PDU}|{Function code\\n1 B|Data\\n0 to 252 B}", fillcolor="#ffffff"];
 n [shape=note, style=filled, fillcolor="#f8f8f8", label="Length counts the bytes that follow it:\\nUnit ID + function code + data"];
 m -> p [style=dotted]; p -> n [style=dotted, arrowhead=none];
""", 800)
D["datamodel"] = ("""
 rankdir=TB; node [shape=record, style=filled, fillcolor="#f2f2f2", width=3.6];
 a [label="{Coils|1 bit, read/write|FC 01, 05, 0F}"];
 b [label="{Discrete inputs|1 bit, read only|FC 02}", fillcolor="#ffffff"];
 c [label="{Holding registers|16 bit, read/write|FC 03, 06, 10, 16, 17}"];
 d [label="{Input registers|16 bit, read only|FC 04}", fillcolor="#ffffff"];
 a -> b -> c -> d [style=invis];
""", 700)
D["rs485"] = ("""
 rankdir=LR; node [shape=box];
 T1 [label="Terminator\\n(120-150 ohm)", shape=ellipse, fillcolor="#dddddd"]; M [label="Master"]; S1 [label="Slave 1", fillcolor="#fff"]; S2 [label="Slave 2", fillcolor="#fff"]; S3 [label="Slave N", fillcolor="#fff"]; T2 [label="Terminator", shape=ellipse, fillcolor="#dddddd"];
 T1 -> M [dir=none, penwidth=2.2]; M -> S1 [dir=none, penwidth=2.2]; S1 -> S2 [dir=none, penwidth=2.2]; S2 -> S3 [dir=none, penwidth=2.2]; S3 -> T2 [dir=none, penwidth=2.2];
""", 800)
D["rs485"] = (D["rs485"][0].replace("rankdir=LR","rankdir=TB"), 600)
D["gateway"] = ("""
 rankdir=TB;
 C1 [label="SCADA client\\n(Modbus TCP)"]; C2 [label="HMI / historian\\n(Modbus TCP)"];
 G [label="Modbus gateway\\nTCP port 502 -> serial line\\nUnit ID = serial slave address", fillcolor="#cccccc"];
 S1 [label="Slave 1\\n(RTU)", fillcolor="#fff"]; S2 [label="Slave 2\\n(RTU)", fillcolor="#fff"]; S3 [label="Slave 3\\n(RTU)", fillcolor="#fff"];
 C1 -> G [label=" TCP"]; C2 -> G [label=" TCP"]; G -> S1 [label=" RS-485"]; G -> S2; G -> S3;
""", 800)
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
def reqresp():
    fig, ax = plt.subplots(figsize=(6.4,5.4), dpi=170)
    ax.set_xlim(0,10); ax.set_ylim(0,9.6); ax.axis("off")
    for x,n in [(2,"Master / client"),(8,"Slave / server")]:
        ax.text(x,9.2,n,ha="center",fontsize=11,weight="bold"); ax.plot([x,x],[0.2,8.9],color="#555",lw=1.3)
    def a(y,x0,x1,t,dash=False):
        ax.annotate("",xy=(x1,y-0.8),xytext=(x0,y),arrowprops=dict(arrowstyle="-|>",lw=1.4,color="#222",ls="--" if dash else "-"))
        ax.text(5,y-0.4,t,ha="center",va="bottom",fontsize=9,bbox=dict(fc="white",ec="none",pad=1))
    a(8.4,2,8,"01 03 00 64 00 0A  + CRC\n(read 10 holding registers from 100)")
    a(6.7,8,2,"01 03 14 ... 20 data bytes ...  + CRC\n(normal response)")
    a(4.5,2,8,"01 03 FF FF 00 01  + CRC\n(read at an address that does not exist)")
    a(2.7,8,2,"01 83 02  + CRC\n(exception: function + 0x80, code 02)",dash=True)
    fig.savefig(OUT+"/reqresp.png",bbox_inches="tight",facecolor="white")
def timing():
    fig, ax = plt.subplots(figsize=(6.6,2.8), dpi=170)
    ax.set_xlim(0,20); ax.set_ylim(0,5); ax.axis("off")
    def box(x,w,t,fc): 
        ax.add_patch(plt.Rectangle((x,2),w,1.2,fc=fc,ec="#222",lw=1.2)); ax.text(x+w/2,2.6,t,ha="center",va="center",fontsize=8.5)
    box(0.5,2.2,"Addr","#eee"); box(2.7,2.2,"Func","#eee"); box(4.9,4.6,"Data","#eee"); box(9.5,2.6,"CRC","#eee")
    ax.annotate("",xy=(14.8,2.6),xytext=(12.1,2.6),arrowprops=dict(arrowstyle="<->",lw=1.2))
    ax.text(13.45,3.45,"silent interval\n>= 3.5 chars",ha="center",fontsize=8)
    box(14.8,2.2,"Addr","#ddd"); box(17,2.6,"Func ...","#ddd")
    ax.annotate("",xy=(4.9,1.6),xytext=(2.7,1.6),arrowprops=dict(arrowstyle="<->",lw=1.2))
    ax.text(3.8,0.8,"gap between characters\nmust stay below 1.5 characters",ha="center",fontsize=8.5)
    ax.text(10,4.8,"One RTU frame, then the next",ha="center",fontsize=10,weight="bold")
    fig.savefig(OUT+"/timing.png",bbox_inches="tight",facecolor="white")
reqresp(); timing()
if __name__=="__main__":
    for k,(b,w) in D.items(): render(k,b,w)
    for f in ["reqresp","timing"]:
        subprocess.run(["convert",f"{OUT}/{f}.png","-resize","1000x>","-colorspace","Gray",f"{OUT}/{f}.png"])
    print(subprocess.run("ls %s/*.png|wc -l"%OUT,shell=True,capture_output=True,text=True).stdout)
