from oc1 import C
C[26] = ("Transaction Identifier Management",
 "The client chooses a transaction ID for each request; the server echoes it so responses can be matched.",
 "The **ticket number at a deli counter**: you take one, they call it back with your order.",
 ["**2-byte ID**, echoed unchanged by the server.","**Increment with wrap-around.**","**Match responses by ID**, not by arrival order.","**Make allocation thread-safe.**","**Discard responses with unknown IDs.**"])
C[27] = ("Multiple Client Handling",
 "A server accepts several TCP connections and must serialise access to shared data.",
 "A **receptionist with several phones ringing**: each caller is served in turn, and the appointment book must not be written by two people at once.",
 ["**One thread, select/poll loop, or a task per connection.**","**Lock or serialise access** to register tables.","**Limit connections** and idle time.","**Per-client state is minimal** in Modbus.","**Fair scheduling** prevents starvation."])
C[28] = ("TCP Keep-Alive Mechanism",
 "SO_KEEPALIVE and application-level probes detect dead connections that never sent a reset.",
 "**Tapping the line now and then** to check that someone is still on the other end.",
 ["**Enable SO_KEEPALIVE** and tune idle, interval and count.","**Defaults are hours** on many systems, far too long.","**Application heartbeat**: a cheap read request.","**Firewalls drop idle flows**; keep traffic flowing.","**Treat failures as disconnects** and reconnect."])
C[29] = ("Big-Endian vs Little-Endian",
 "Modbus sends each 16-bit register high byte first; the order of registers inside 32-bit and larger values is up to the device.",
 "Reading **a number written in two halves on two cards**: each card is read left to right (big-endian within the register), but which card comes first is the vendor's choice.",
 ["**Registers are always high byte first** on the wire.","**Multi-register values** have no standard order.","**Four common orders**: ABCD, CDAB, BADC, DCBA (A = most significant byte).","**Test with a known value** such as 0x12345678.","**Make the order configurable.**"])
C[30] = ("32-bit Integer Handling",
 "A 32-bit value occupies two registers; the order is ABCD, CDAB, BADC or DCBA depending on the device.",
 "The **two-card number again**: ABCD = high card first; CDAB = low card first (word swap); BADC = bytes swapped inside each card; DCBA = everything reversed.",
 ["**For 0x12345678**: ABCD = [1234, 5678]; CDAB = [5678, 1234]; BADC = [3412, 7856]; DCBA = [7856, 3412].","**CDAB swaps only the words**, bytes stay in order.","**Be explicit about signed vs unsigned.**","**Write both registers in one FC 10** request.","**Document the order** per device."])
C[31] = ("IEEE 754 Floating Point",
 "A 32-bit float is two registers with the same ordering ambiguity; a 64-bit double needs four.",
 "Same **two-card trick**, but the number on the cards is encoded as sign, exponent and fraction.",
 ["**Single precision**: 1 sign, 8 exponent, 23 fraction bits.","**Word order varies** by device; ABCD and CDAB are most common.","**0x41C80000 is 25.0** in IEEE 754.","**NaN and infinity** need handling.","**Some devices require even starting addresses**; that is a device rule, not Modbus."])
C[32] = ("Bit Manipulation",
 "Status words pack many flags into one register; mask, shift and test individual bits.",
 "A **row of tiny flags on one flagpole**: each bit raises or lowers one flag.",
 ["**Test**: `(reg >> n) & 1`.","**Set**: `reg |= (1 << n)`; **clear**: `reg &= ~(1 << n)`.","**Read-modify-write is not atomic**; consider FC 16.","**Bit 0 is the least significant bit.**","**Use unsigned types** when shifting."])
C[33] = ("Register Scaling and Conversion",
 "Devices store engineering values as scaled integers; convert with scale and offset.",
 "**Prices in cents**: 2530 means 25.30, and everybody must know the factor.",
 ["**value = raw x scale + offset.**","**Scaling lives in the device map**, not in the protocol.","**Beware signed 16-bit** values (two's complement).","**Check overflow and rounding.**","**Keep raw values** for diagnostics."])
C[34] = ("String Data Handling",
 "Text is packed two characters per register, usually high byte first, and padded with spaces or zeros.",
 "**Two letters per card**: a name is spread over several cards, padded at the end.",
 ["**Two ASCII characters per register.**","**First character in the high byte** is typical; check the device.","**Fixed length**, space or NUL padded.","**Trim padding** when reading.","**Validate length** when writing."])
C[35] = ("Slave/Server Implementation",
 "A server validates each request, reads or writes its data tables and builds a response or exception.",
 "The **pupil's side of the roll call**: listen for your number, check that the question makes sense, answer or explain why not.",
 ["**Check address, function, quantity, then execute.**","**Return exception 01, 02 or 03** as appropriate.","**Ignore frames for other addresses.**","**Do not answer broadcasts.**","**Keep data tables consistent** under concurrent access."])
C[36] = ("Master/Client Implementation",
 "A client builds requests, waits for responses within a timeout, validates them and retries sensibly.",
 "The **teacher's side**: ask, wait a reasonable time, check the answer is from the right pupil, ask again if needed.",
 ["**Validate address, function and CRC** of responses.","**Timeout per request.**","**Limited retries**, then mark the device offline.","**One outstanding request per serial bus.**","**Handle exceptions separately from timeouts.**"])
C[37] = ("Data Model and Address Mapping",
 "Four tables with independent zero-based address spaces; traditional 0xxxx to 4xxxx notation adds a type prefix and a one-based offset.",
 "**Four cabinets**: two with switches, two with number cards. The old labels (40001 and so on) are **catalogue numbers**; the protocol uses the position in the drawer, starting at 0.",
 ["**Holding register 40001 is protocol address 0.**","**Coils 0xxxx, discrete inputs 1xxxx, input registers 3xxxx, holding registers 4xxxx.**","**Six-digit notation** (e.g. 400001) covers all 65,536 addresses.","**Check whether the device manual is one-based.**","**Off-by-one is the top integration bug.**"])
C[38] = ("Register Database Design",
 "Structure server data tables for fast access, metadata and change tracking.",
 "A **well-organised filing cabinet** with an index, so lookups are fast and nothing is mislabelled.",
 ["**Contiguous arrays** for speed.","**Metadata per register** (name, type, scale, access).","**Change flags** for event-driven updates.","**Protect with locks** or double buffering.","**Persist** configuration registers."])
C[39] = ("Polling Strategies",
 "Choose polling rates and grouping to balance freshness against bus load.",
 "A **postman's round**: critical houses visited every hour, others once a day.",
 ["**Group contiguous registers** into one request.","**Different rates** for fast and slow data.","**Skip offline devices** and probe them rarely.","**Bus utilisation** at 9600 baud is low: budget it.","**Avoid polling faster than the device updates.**"])
C[40] = ("Request Queuing",
 "A queue serialises requests from many producers onto one bus or connection.",
 "A **single-lane toll booth**: cars queue, each gets served in turn.",
 ["**One outstanding request on a serial bus.**","**Priority** for urgent writes.","**Bound the queue** and decide what to drop.","**Timeouts per item.**","**Report queue depth.**"])
C[41] = ("Retry Logic and Timeout Handling",
 "Retry transient failures with limits and backoff; do not retry what cannot succeed.",
 "**Calling again after a busy signal**, but not forever and not for a wrong number.",
 ["**Retry timeouts and CRC errors**, a few times.","**Do not retry** exception 01, 02 or 03.","**Exception 06 (busy)**: wait and retry.","**Writes**: be careful, a retry may repeat an action.","**Mark device offline** after repeated failures."])
C[42] = ("Error Detection and Recovery",
 "Detect corrupt frames, loss of sync and dead devices, and resynchronise.",
 "**Noticing a garbled phone call, hanging up and redialling.**",
 ["**CRC/LRC failure**: discard, do not answer.","**Resync** by waiting for a 3.5-character silence.","**Flush buffers** before retrying.","**Reopen serial ports/sockets** after hard faults.","**Count errors** per device."])
C[43] = ("Thread Safety and Concurrency",
 "Shared register tables and connections need synchronisation.",
 "A **shared whiteboard**: two people writing at once leave a mess.",
 ["**Mutex or RW lock** around data tables.","**Own each connection in one thread.**","**Avoid holding locks during I/O.**","**Atomic counters** for statistics.","**Test with thread sanitizers.**"])
C[44] = ("Asynchronous I/O",
 "Non-blocking I/O lets one thread manage many connections or devices.",
 "A **waiter serving many tables** instead of standing at one.",
 ["**select/poll/epoll** or async runtimes.","**State machine per connection.**","**Timers** for timeouts.","**Back-pressure**: do not queue without limit.","**Cancel safely** on shutdown."])
C[45] = ("Performance Optimization",
 "Reduce round trips, batch registers, reuse connections and avoid needless copies.",
 "**Fewer, bigger trips**: one trolley full of shopping instead of ten trips for single items.",
 ["**Read blocks of up to 125 registers.**","**FC 17** to combine write and read.","**Persistent connections.**","**Pipeline TCP requests** if the device allows.","**Measure** before optimising."])
C[46] = ("Circular Buffer Implementation",
 "A ring buffer decouples ISR or I/O threads from frame parsing.",
 "A **carousel**: items are added at one point and removed at another, round and round.",
 ["**Head and tail indices**, power-of-two size for cheap wrap.","**Single producer, single consumer** can be lock-free.","**Detect full vs empty** unambiguously.","**Size for the longest frame** (256 bytes for RTU) plus margin.","**Overrun counters** reveal lost bytes."])
C[47] = ("Modbus Security Considerations",
 "Classic Modbus has no authentication, encryption or authorisation; rely on segmentation, firewalls and, where possible, Modbus/TCP Security.",
 "An **intercom with no password**: anyone who picks up the handset can give orders. Security therefore has to come from the building around it.",
 ["**No built-in security** in RTU, ASCII or TCP.","**Segment and firewall** control networks.","**Deep-inspection industrial firewalls** can filter by function code and address.","**Modbus/TCP Security** wraps the protocol in mutual TLS.","**Log and monitor** writes."])
C[48] = ("Protocol Analyzers and Debugging",
 "Wireshark decodes Modbus TCP; serial taps and logic analysers show RTU timing.",
 "A **stethoscope for the wire**.",
 ["**Wireshark filter `mbtcp`** (port 502).","**Serial**: RS-485 sniffer or USB adapter in listen-only mode.","**Check CRC, address, function.**","**Look at timing gaps** for RTU problems.","**Compare request and response** field by field."])
C[49] = ("Diagnostic Counters",
 "Counters for messages, CRC errors, exceptions and no-responses support health monitoring.",
 "The **odometer and warning lights** of a communication link.",
 ["**Bus message, bus communication error, bus exception, slave message, slave no-response** counters.","**Readable with FC 08** sub-functions on serial lines.","**Clear with sub-function 0x000A.**","**Rising CRC errors** point to noise, wiring or parity mismatch.","**Mirror counters in your own software** for TCP."])
C[50] = ("Unit Testing Strategies",
 "Test CRC/LRC, parsers and state machines against known vectors.",
 "**Checking the ruler before you measure.**",
 ["**Use published vectors** (e.g. CRC `C5 CD` for `01 03 00 00 00 0A`).","**Test every exception path.**","**Fuzz** frame parsers.","**Mock the transport.**","**Test boundary quantities** (1, 125, 126)."])
C[51] = ("Function Code 0x07: Read Exception Status",
 "FC 07 returns one byte of device-specific status bits; serial line only.",
 "A **quick glance at the warning lights**.",
 ["**Request has no data**; response is one byte.","**Bit meanings are vendor-defined.**","**Serial line only** (not defined for Modbus TCP).","**RTU request is 4 bytes, response 5.**","**Cheap health poll.**"])
C[52] = ("Function Code 0x08: Diagnostics",
 "FC 08 offers sub-functions for loopback, restart, listen-only mode and communication counters; serial line only.",
 "The **maintenance panel** behind the front cover.",
 ["**0x0000** return query data (echo test).","**0x0001** restart communications; **0x0004** force listen-only.","**0x000A** clear counters; **0x000B to 0x0012** return various counters.","**Serial line only.**","**Sub-function is a 2-byte field.**"])
C[53] = ("Function Code 0x0B: Get Comm Event Counter",
 "FC 0B returns a status word and a counter of successfully completed messages; serial line only.",
 "A **tally counter** at the door that counts only successful visits.",
 ["**Response**: status (2) + event count (2).","**Status 0xFFFF means a program command is still being processed**, 0x0000 means not busy.","**Counts successful messages**, not exceptions or its own polls.","**Wraps at 65535.**","**Serial line only.**"])
C[54] = ("Function Code 0x0C: Get Comm Event Log",
 "FC 0C returns status, event count, message count and up to 64 event bytes; serial line only.",
 "The **black-box recorder** of the link.",
 ["**Response**: byte count, status, event count, message count, events.","**Up to 64 event bytes**, newest first.","**Receive events have bit 7 set**; send events have bit 7 clear and bit 6 set.","**0x00 is a communication-restart event, 0x04 is listen-only mode entered.**","**Serial line only.**"])
C[55] = ("Function Code 0x14: Read File Record",
 "FC 14 reads records from numbered files using sub-requests with reference type 6.",
 "A **library lookup**: file number, record number, how many words.",
 ["**Reference type is always 0x06.**","**File 1 to 65535, record 0 to 9999.**","**Several sub-requests per message**, limited by the 253-byte PDU.","**Response lengths are in bytes.**","**Support is rare**; check the device."])
C[56] = ("Function Code 0x15: Write File Record",
 "FC 15 writes records into numbered files; the response echoes the request.",
 "**Filing a document in the right folder.**",
 ["**Reference type 0x06.**","**Request data length up to 251 bytes.**","**Response echoes** the request.","**Rarely implemented.**","**Validate lengths carefully.**"])
C[57] = ("Function Code 0x16: Mask Write Register",
 "FC 16 changes selected bits of one register: result = (current AND and_mask) OR (or_mask AND NOT and_mask).",
 "**A stencil**: the AND mask decides which bits survive, the OR mask paints new ones into the cleared spots.",
 ["**Formula** as above.","**Request**: address, and_mask, or_mask (7 bytes PDU).","**Response echoes the request.**","**Set bit n**: and_mask = 0xFFFF, or_mask = 1 << n.","**Atomic bit change** without a read-modify-write race."])
C[58] = ("Function Code 0x18: Read FIFO Queue",
 "FC 18 reads the current contents of a register FIFO without removing them.",
 "**Peeking at the queue** without taking anyone out of it.",
 ["**Request**: FIFO pointer address.","**Response**: byte count (2), FIFO count (2), values.","**At most 31 registers.**","**Does not consume data.**","**Rarely implemented.**"])
C[59] = ("Function Code 0x2B: Encapsulated Interface Transport",
 "FC 2B/MEI type 0x0E reads device identification objects such as vendor name and product code.",
 "The **ID plate** on the machine.",
 ["**MEI type 0x0E**: Read Device Identification; **0x0D**: CANopen general reference.","**Read device ID codes** 01 basic, 02 regular, 03 extended, 04 single object.","**Object IDs**: 00 vendor, 01 product code, 02 revision, 03 URL, 04 product name, 05 model, 06 application name.","**Basic identification is mandatory** where supported.","**Works on serial and TCP.**"])
C[60] = ("Custom Function Codes",
 "User-defined codes live in 65 to 72 and 100 to 110; everything else is public or reserved.",
 "A **private lane** on the road: yours to use, but nobody else knows the rules.",
 ["**User-defined: 65 to 72 (0x41 to 0x48) and 100 to 110 (0x64 to 0x6E).**","**Follow the PDU rules**: exception = code + 0x80.","**Document and version** them.","**Do not depend on them for interoperability.**","**Gateways may reject unknown codes.**"])
