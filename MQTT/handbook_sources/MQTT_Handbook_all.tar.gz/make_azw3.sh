#!/bin/bash
# Convert the EPUB to AZW3 for Kindle Scribe with Calibre.
IN=MQTT_Handbook.epub
OUT=MQTT_Handbook.azw3
PROFILE=kindle_scribe
ebook-convert "$IN" "$OUT" --output-profile "$PROFILE" \
  --change-justification left --no-inline-toc \
  --chapter-mark none --page-breaks-before "//h:h1" \
  --disable-font-rescaling --mobi-file-type new
# If your Calibre is older and rejects kindle_scribe, use: --output-profile kindle_oasis
